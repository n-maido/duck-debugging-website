CMPT362 Project Group 1
###Special Instructions:
News API: Please note that we are using the free tier, which limits us to 2000 articles per day.
Most of the logical/database operations are done in files under java/models/firebase, please have a look there
for explanations to functionalities.