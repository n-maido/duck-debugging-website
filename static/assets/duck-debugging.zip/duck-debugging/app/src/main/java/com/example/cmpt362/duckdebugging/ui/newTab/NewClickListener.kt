package com.example.cmpt362.duckdebugging.ui.newTab

interface NewClickListener {
    fun onClickNotification(data_time: String, questionId: String, questionTitle: String,
                            reply_body: String, responderName: String,
                            notificationId: String ,responderKeyForDeletion : String, position: Int)
}
