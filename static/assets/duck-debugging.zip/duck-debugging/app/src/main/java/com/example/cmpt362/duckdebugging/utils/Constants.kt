package com.example.cmpt362.duckdebugging.utils

import android.app.Activity
import android.content.Intent
import android.provider.MediaStore

object Constants {
    const val USERS: String = "users"
    const val ID: String = "id"
    const val FIRST_NAME: String = "firstName"
    const val LAST_NAME: String = "lastName"
    const val EMAIL: String = "email"
    const val OCCUPATION: String = "occupation"
    const val IMAGE: String = "image"
    const val PROFILE_COMPLETED = "profileComplete"
    const val DUCK_DEBUGGING_PREFERENCES: String = "MyDuckDebuggingPrefs"
    const val LOGGED_IN_USERNAME: String = "logged_in_username"
    const val EXTRA_USER_DETAILS: String = "extra_user_details"
    const val READ_STORAGE_PERMISSION_CODE = 20
    const val PICK_IMAGE_REQUEST_CODE = 30
    const val POSTS = "posts"
    const val PROFILE_IMAGE_OF_USER_FIRE_STORE = "Profile_image_of_the_user"
    const val MY_PROFILE_PICTURE = "myPic.jpeg"
    const val REPLIES = "replies"
    const val REPLIES_ID_LIST = "replies_id_list"

    const val USER_ID: String = "userId"
    const val BASE_URL = "http://fcm.googleapis.com"
    const val SERVER_KEY = "AIzaSyAH9j_OuoZiPOL7CbRZQSjY3zaC97rep8Q"
    const val CONTENT_TYPE = "application/json"
    const val NOTIFY_RECEIVER = "notify_receiver"
    const val USER_TOKEN = "userToken"
    const val NOTIFY_RECEIVER_ID = "notify_receiver_ID"
    const val COLLECTION_NOTIFICATION = "notification_list_for_each_user"

    // Select an image for the app
    fun showImageChooser(activity: Activity){
        // An intent for lunching the image selection of phone storage
        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        // Lunch the image selection
        activity.startActivityForResult(galleryIntent, PICK_IMAGE_REQUEST_CODE)
    }
}