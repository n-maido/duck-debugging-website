package com.example.cmpt362.duckdebugging.ui.loginAndRegisterPage


import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.cmpt362.duckdebugging.R
import com.google.android.material.snackbar.Snackbar

/**
    * To create a snackBar when validating user entries
    * It is open because we want to other activities inherent from BaseActivity()
 */
open class BaseActivity : AppCompatActivity() {

    fun showErrorSnackBar(message: String, errorMessage: Boolean){
        val snakeBar = Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG)
        val snackBarView = snakeBar.view

        if(errorMessage) {
            snackBarView.setBackgroundColor(
                ContextCompat.getColor(
                    this@BaseActivity, R.color.colorSnakeBarError
                )
            )
        }
        else{
            snackBarView.setBackgroundColor(
                ContextCompat.getColor(
                    this@BaseActivity,
                    R.color.colorSnackBarSuccess
                )
            )
        }
        snakeBar.show()
    }

}