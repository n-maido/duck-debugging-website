package com.example.cmpt362.duckdebugging.ui.newTab

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.cmpt362.duckdebugging.models.firebase.FirebaseDataBaseClass
import com.example.cmpt362.duckdebugging.models.users.NotificationModel

class NewViewModel : ViewModel() {
    var notificationList = MutableLiveData<ArrayList<NotificationModel>>()

    init {
//
    }

    private val _text = MutableLiveData<String>().apply {
        value = "This is New Fragment"
    }
    val text: LiveData<String> = _text

    fun setCategories(list: ArrayList<NotificationModel>) {
        notificationList.value = list
    }

}