package com.example.cmpt362.duckdebugging.ui.postTab

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.cmpt362.duckdebugging.R
import com.example.cmpt362.duckdebugging.models.firebase.FirebaseDataBaseClass
import com.example.cmpt362.duckdebugging.models.posts.Post
import java.util.UUID

// create new question/post in database according to users' inputs
class NewPostActivity : AppCompatActivity() {
    private lateinit var question_category: String
    private lateinit var question_title: String
    private lateinit var question_body: String
    private lateinit var post_model: Post
    private lateinit var post_btn: Button
    private lateinit var dataBaseClass: FirebaseDataBaseClass

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_post)
        post_btn = findViewById(R.id.new_post_btn)
        dataBaseClass = FirebaseDataBaseClass()
        post_btn.setOnClickListener({
            question_category = intent.getStringExtra("category").toString()
            val question_title_view: EditText = findViewById(R.id.new_post_question)
            val question_body_view: EditText = findViewById(R.id.question_body_input)
            question_title = question_title_view.text.toString()
            question_body = question_body_view.text.toString()
            post_model = Post(UUID.randomUUID().toString(), question_title, question_body, dataBaseClass.getCurrentUserID())
            dataBaseClass.postQuestionForCategory(question_category, post_model, this)
        })
    }

    fun onPostSuccess() {
        Toast.makeText(this, "Posted question.", Toast.LENGTH_SHORT).show()
        finish()
    }
}