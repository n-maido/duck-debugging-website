package com.example.cmpt362.duckdebugging.ui.newTab.NotificationWindowActivity

import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import com.example.cmpt362.duckdebugging.MainActivity
import com.example.cmpt362.duckdebugging.R
import com.example.cmpt362.duckdebugging.databinding.ActivityNotificationWindowBinding
import com.example.cmpt362.duckdebugging.models.firebase.FirebaseDataBaseClass
import com.example.cmpt362.duckdebugging.ui.newTab.recyclerViewInNotificationWindow

/**
 * Shows the whole details of a responds to a question
 */
class NotificationWindowActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNotificationWindowBinding
    lateinit var view : LinearLayout
    lateinit var returnBtn : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationWindowBinding.inflate(layoutInflater)

        val dataTimeOfResponse : String =
            intent.getStringExtra("data_time_notification_responder").toString()
        val position = intent.getIntExtra("position_notification_list", 0)
        val questionTitle : String =
            intent.getStringExtra("question_title_notification").toString()
        val replyBody : String =
            intent.getStringExtra("reply_body_notification").toString()
        val responderName : String =
            intent.getStringExtra("responder_name_notification").toString()
        val notificationId : String =
            intent.getStringExtra("notification_id").toString()
        val keyForDeletion : String =
            intent.getStringExtra("responderKeyForDeletion").toString()

        FirebaseDataBaseClass().deleteANotification(keyForDeletion,notificationId, recyclerViewInNotificationWindow!!.adapter)
        binding.responderNameTextViewID.text = responderName
        binding.questionTitleTextviewId.text = questionTitle
        binding.replyBodyTextView.text = replyBody
        binding.dataTimeTextViewId.text = dataTimeOfResponse
        view = binding.linearlayoutNotify
        returnBtn = binding.returnBtnToNotification
        returnBtn.setOnClickListener {
            val valueAnimator = ValueAnimator.ofFloat(0.0f, 1.0f)
            valueAnimator.duration = 325
            valueAnimator.addUpdateListener { valueAnimator ->
                val fractionAnim = valueAnimator.animatedValue as Float
                view.setBackgroundColor(
                    ColorUtils.blendARGB(
                        Color.parseColor("#ff716f"),
                        Color.parseColor("#ff716f"),
                        fractionAnim
                    )
                )
            }
            valueAnimator.start()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            overridePendingTransition(
                R.anim.slide_in_bottom,
                R.anim.slide_out_up);
        }
        setContentView(binding.root)
    }
    override fun onBackPressed() {
        val valueAnimator = ValueAnimator.ofFloat(0.0f, 1.0f)
        valueAnimator.duration = 325
        valueAnimator.addUpdateListener { valueAnimator ->
            val fractionAnim = valueAnimator.animatedValue as Float
            view.setBackgroundColor(
                ColorUtils.blendARGB(
                    Color.parseColor("#ff716f"),
                    Color.parseColor("#ff716f"),
                    fractionAnim
                )
            )
        }
        valueAnimator.start()
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        overridePendingTransition(
            R.anim.slide_in_bottom,
            R.anim.slide_out_up);
    }

}