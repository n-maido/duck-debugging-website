package com.example.cmpt362.duckdebugging.models.articles

data class Article(
    val heading: String,
    val outlet: String,
    val url: String,
    val imageUrl: String
){}
