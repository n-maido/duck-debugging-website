package com.example.cmpt362.duckdebugging.models.articles

/**
 * News article object
 * Each article is displayed in the newsfeed tab
 */
data class Article(
    val heading: String,
    val outlet: String,
    val url: String,
    val imageUrl: String
){}
