package com.example.cmpt362.duckdebugging.models.users


/**
 * Notification model
 */
class NotificationModel (
    val reply_body : String = "",
    val data_time : String = "",
    val question_id : String = "",
    val question_title : String = "",
    val responderName : String = "",
    val notificationId: String = "",
    val responderKeyForDeletion: String = "")