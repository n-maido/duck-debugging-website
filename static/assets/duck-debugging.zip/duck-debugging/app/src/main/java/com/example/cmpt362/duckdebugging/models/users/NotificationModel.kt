package com.example.cmpt362.duckdebugging.models.users

class NotificationModel (
    val reply_body : String = "",
    val data_time : String = "",
    val question_title : String = "",
    val responderName : String = "",
    val notificationId: String = "",
    val responderKeyForDeletion: String = "")