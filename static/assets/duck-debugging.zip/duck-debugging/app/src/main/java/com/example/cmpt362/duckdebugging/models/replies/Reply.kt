package com.example.cmpt362.duckdebugging.models.replies

class Reply(val description: String = "", val userId: String = "") {
}