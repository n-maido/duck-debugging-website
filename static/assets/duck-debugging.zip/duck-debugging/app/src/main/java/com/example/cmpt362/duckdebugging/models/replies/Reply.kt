package com.example.cmpt362.duckdebugging.models.replies
// content of a single Reply object, reply_id is unique
class Reply(val description: String = "", val userId: String = "", val reply_id: String = "", val levels: ArrayList<String> = arrayListOf()) {
}