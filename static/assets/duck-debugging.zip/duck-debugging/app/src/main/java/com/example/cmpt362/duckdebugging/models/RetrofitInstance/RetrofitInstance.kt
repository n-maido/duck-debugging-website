package com.example.cmpt362.duckdebugging.models.RetrofitInstance

import com.example.cmpt362.duckdebugging.`interface`.NotificationApi
import com.example.cmpt362.duckdebugging.utils.Constants
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RetrofitInstance {
    companion object{
        private val retrofit by lazy{
            Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        }

        val api by lazy{
            retrofit.create(NotificationApi::class.java)
        }
    }
}