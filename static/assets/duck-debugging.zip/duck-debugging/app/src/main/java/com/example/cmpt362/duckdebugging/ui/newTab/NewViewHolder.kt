package com.example.cmpt362.duckdebugging.ui.newTab

import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.NewViewHolderBinding


class NewViewHolder (
    val binding: NewViewHolderBinding,
): RecyclerView.ViewHolder(binding.root) {

}