package com.example.cmpt362.duckdebugging.ui.postTab.replyPage

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.cmpt362.duckdebugging.R
import com.example.cmpt362.duckdebugging.models.RetrofitInstance.RetrofitInstance
import com.example.cmpt362.duckdebugging.models.firebase.FCMSend
import com.example.cmpt362.duckdebugging.models.firebase.FirebaseDataBaseClass
import com.example.cmpt362.duckdebugging.models.firebase.NotificationData
import com.example.cmpt362.duckdebugging.models.firebase.PushNotification
import com.example.cmpt362.duckdebugging.models.replies.Reply
import com.example.cmpt362.duckdebugging.utils.Constants
import com.google.firebase.installations.FirebaseInstallationsRegistrar
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.util.*

class NewReplyActivity : AppCompatActivity() {
    private lateinit var reply_btn: Button
    private lateinit var reply_body: String
    private lateinit var reply_model: Reply
    private lateinit var dataBaseClass: FirebaseDataBaseClass
    private lateinit var question_category: String
    private lateinit var question_id: String

    var topic = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_reply)
        reply_btn = findViewById(R.id.new_reply_btn)
        dataBaseClass = FirebaseDataBaseClass()

        val currentUserId = dataBaseClass.getCurrentUserID()
        question_category = intent.getStringExtra("question_category").toString()
        question_id = intent.getStringExtra("question_id").toString()
       FirebaseDataBaseClass().getTheUserIdForNotification(question_category, question_id, this)
        reply_btn.setOnClickListener({
            val time = Calendar.getInstance().time
            val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm")
            val current = formatter.format(time)
            val sharedPreferences =getSharedPreferences(Constants.DUCK_DEBUGGING_PREFERENCES, Context.MODE_PRIVATE)
            val receivingUserNotification = sharedPreferences.getString(Constants.NOTIFY_RECEIVER, "")!!
            val receivingUserNotificationId = sharedPreferences.getString(Constants.NOTIFY_RECEIVER_ID, "")!!
            val reply_body_view: EditText = findViewById(R.id.reply_body_input)
            reply_body = reply_body_view.text.toString()
            reply_model = Reply(reply_body, dataBaseClass.getCurrentUserID())
            dataBaseClass.postReplyToQuestion(question_category, question_id, reply_model, this)
            if(currentUserId != receivingUserNotificationId) {
                dataBaseClass.addNotificationToUser(receivingUserNotificationId, reply_body,currentUserId,
                    current,question_id)
                FCMSend.pushNotification(
                    this,
                    receivingUserNotification,
                    question_id,
                    "A Nice Person Response To Your Question"
                )
            }
        })

    }

    fun onReplySuccess() {
        Toast.makeText(this, "Posted reply.", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun sendNotification(notification: PushNotification) = CoroutineScope(Dispatchers.IO).launch {
        try{
            val response = RetrofitInstance.api.postNotification(notification)
            if(response.isSuccessful){
                Toast.makeText(this@NewReplyActivity, "Response ${Gson().toJson(response)}", Toast.LENGTH_SHORT).show()
            }
            else{
                Toast.makeText(this@NewReplyActivity, response.errorBody().toString(), Toast.LENGTH_SHORT).show()
            }
        }catch(e : java.lang.Exception){
            Toast.makeText(this@NewReplyActivity, e.message , Toast.LENGTH_SHORT).show()
        }

    }
}