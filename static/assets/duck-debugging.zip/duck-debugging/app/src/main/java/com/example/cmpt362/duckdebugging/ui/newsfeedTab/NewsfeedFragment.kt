package com.example.cmpt362.duckdebugging.ui.newsfeedTab

import android.content.Intent
import android.net.Uri
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.FragmentNewsfeedBinding
import com.example.cmpt362.duckdebugging.models.articles.Article
import com.example.cmpt362.duckdebugging.models.posts.Post

class NewsfeedFragment : Fragment(), NewsfeedClickListener {

    private var _binding: FragmentNewsfeedBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private lateinit var newsfeedViewModel: NewsfeedViewModel
    private lateinit var articles: ArrayList<Article>
    private lateinit var adapter: NewsfeedRecyclerViewAdapter
    private lateinit var searchView: SearchView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        newsfeedViewModel =
            ViewModelProvider(this).get(NewsfeedViewModel::class.java)

        _binding = FragmentNewsfeedBinding.inflate(inflater, container, false)
        val root: View = binding.root

        //initialize adapter and pass to recycler view
        articles = ArrayList<Article>()
        val recyclerView: RecyclerView = binding.newsfeedRecyclerView
        adapter = NewsfeedRecyclerViewAdapter(this, articles)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        newsfeedViewModel.fetchArticles(requireContext(), articles, adapter)

        //search for articles
        searchView = binding.articleSearch
        searchView.clearFocus()
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    filterArticles(query.lowercase())
                }
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText != null) {
                    filterArticles(newText.lowercase())
                }
                return false
            }
        })

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onClickArticle(url: String) {
        // open the article url in a browser
        val articleWebpageIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        startActivity(articleWebpageIntent)
    }

    private fun filterArticles(query: String) {
        var filteredArticles: ArrayList<Article> = ArrayList<Article>()

        for (article: Article in articles) {
            if (article.heading.lowercase().contains(query) || article.outlet.lowercase().contains(query)) {
                filteredArticles.add(article)
            }
        }

        // send to adapter
        adapter.setFilteredArticles(filteredArticles)
    }
}