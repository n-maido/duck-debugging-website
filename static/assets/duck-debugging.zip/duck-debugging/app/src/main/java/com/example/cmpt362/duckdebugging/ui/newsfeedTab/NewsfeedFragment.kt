package com.example.cmpt362.duckdebugging.ui.newsfeedTab

import android.content.Intent
import android.net.Uri
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.FragmentNewsfeedBinding
import com.example.cmpt362.duckdebugging.models.articles.Article
import com.example.cmpt362.duckdebugging.models.posts.Post

/**
 * Displays the current top tech news articles in a recycler view
 * Each article is displayed in a card, held in a recycler view holder
 */
class NewsfeedFragment : Fragment(), NewsfeedClickListener {

    private var _binding: FragmentNewsfeedBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private lateinit var newsfeedViewModel: NewsfeedViewModel // used to make fetch articles from the NewsData API
    private lateinit var articles: ArrayList<Article>
    private lateinit var adapter: NewsfeedRecyclerViewAdapter
    private lateinit var searchView: SearchView

    companion object {
        private lateinit var recyclerView: RecyclerView
    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        newsfeedViewModel =
            ViewModelProvider(this).get(NewsfeedViewModel::class.java)

        _binding = FragmentNewsfeedBinding.inflate(inflater, container, false)
        val root: View = binding.root

        //initialize the recycler view and adapter and pass to the recycler view model
        articles = ArrayList<Article>()
        recyclerView = binding.newsfeedRecyclerView
        adapter = NewsfeedRecyclerViewAdapter(this, articles)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        NewsfeedViewModel().fetchArticles(requireActivity(), articles, adapter) // fetch the articles from the API
//        adapter.notifyDataSetChanged()

        //search for articles
        searchView = binding.articleSearch
        searchView.clearFocus()
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    filterArticles(query.lowercase())
                }
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText != null) {
                    filterArticles(newText.lowercase())
                }
                return false
            }
        })

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // opens the article url in a browser
    override fun onClickArticle(url: String) {
        val articleWebpageIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        startActivity(articleWebpageIntent)
    }

    // filters our array of articles for articles that match the search query
    private fun filterArticles(query: String) {
        var filteredArticles: ArrayList<Article> = ArrayList<Article>()

        for (article: Article in articles) {
            if (article.heading.lowercase().contains(query) || article.outlet.lowercase().contains(query)) {
                filteredArticles.add(article)
            }
        }

        // send the filtered articles to adapter
        adapter.updateArticles(filteredArticles)
    }
}