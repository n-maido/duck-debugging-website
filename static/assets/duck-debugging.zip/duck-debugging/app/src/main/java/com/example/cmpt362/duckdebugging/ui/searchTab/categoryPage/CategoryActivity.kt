package com.example.cmpt362.duckdebugging.ui.searchTab.categoryPage

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.ActivityCategoryBinding
import com.example.cmpt362.duckdebugging.models.firebase.FirebaseDataBaseClass
import com.example.cmpt362.duckdebugging.models.posts.Post
import com.example.cmpt362.duckdebugging.ui.questionThreadPage.QuestionThreadActivity
import kotlin.collections.ArrayList

class CategoryActivity : AppCompatActivity(), QuestionClickListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: QuestionRecyclerViewAdapter
    private lateinit var binding: ActivityCategoryBinding
    private lateinit var posts:ArrayList<Post>
    private lateinit var searchView: SearchView

    private lateinit var category: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        category = intent.getStringExtra("category").toString()
        val position = intent.getIntExtra("position", 0)
        posts = ArrayList<Post>()


        binding = ActivityCategoryBinding.inflate(layoutInflater)
        recyclerView = binding.categoryRecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)

        if (category != null) {
            adapter = QuestionRecyclerViewAdapter(this, posts)
            recyclerView.adapter = adapter
            FirebaseDataBaseClass().getPostsByCategory(this, category, posts, adapter)
        }

        binding.categoryHeading.text = category

        searchView = binding.categorySearch
        searchView.clearFocus()
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    filterPosts(query.lowercase())
                }
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText != null) {
                    filterPosts(newText.lowercase())
                }
                return false
            }
        })

        setContentView(binding.root)
    }

    private fun filterPosts(query: String) {
        var filteredPosts: ArrayList<Post> = ArrayList<Post>()

        for (post: Post in posts) {
            if (post.title.lowercase().contains(query) || post.body.lowercase().contains(query)) {
                filteredPosts.add(post)
            }
        }

        // send to adapter
        adapter.setFilteredPosts(filteredPosts)
    }

    override fun onClickPost(post: Post, position: Int) {
        println("DEBUG: post clicked")
        // go to the question thread page
        val intent = Intent(this, QuestionThreadActivity::class.java)
        intent.putExtra("category", category)
        intent.putExtra("questionTitle", post.title)
        intent.putExtra("questionBody", post.body)
        startActivity(intent)
    }

}