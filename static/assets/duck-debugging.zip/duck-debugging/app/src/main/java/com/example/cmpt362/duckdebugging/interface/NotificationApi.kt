package com.example.cmpt362.duckdebugging.`interface`

import com.example.cmpt362.duckdebugging.models.firebase.PushNotification
import com.example.cmpt362.duckdebugging.utils.Constants.CONTENT_TYPE
import com.example.cmpt362.duckdebugging.utils.Constants.SERVER_KEY
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body

import retrofit2.http.Headers
import retrofit2.http.POST

interface NotificationApi {

    @Headers("Authorization: key=$SERVER_KEY","Content-type:$CONTENT_TYPE")
    @POST("fcm/send")
    suspend fun postNotification(
        @Body notification : PushNotification
    ): Response<ResponseBody>
}