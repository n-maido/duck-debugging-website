package com.example.cmpt362.duckdebugging.ui.searchTab

import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.SearchViewHolderBinding

/**
 * Holds a card view that displays a category
 * Used by the recycler view in the search tab
 */
class SearchViewHolder(
    val binding: SearchViewHolderBinding,
): RecyclerView.ViewHolder(binding.root) {

}