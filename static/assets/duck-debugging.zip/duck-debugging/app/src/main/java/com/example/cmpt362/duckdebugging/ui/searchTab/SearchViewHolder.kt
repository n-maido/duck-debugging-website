package com.example.cmpt362.duckdebugging.ui.searchTab

import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.SearchViewHolderBinding

class SearchViewHolder(
    val binding: SearchViewHolderBinding,
): RecyclerView.ViewHolder(binding.root) {

}