package com.example.cmpt362.duckdebugging.ui.questionThreadPage

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.QuestionThreadViewHolderBinding
import com.example.cmpt362.duckdebugging.models.replies.Reply
import com.example.cmpt362.duckdebugging.ui.postTab.replyPage.NewReplyActivity

/**
 * Takes in an array of replies and returns a view holder
 * For each reply, update a card view to display the reply info
 */
class QuestionThreadRecyclerViewAdapter(private var replies: ArrayList<Reply>, private var questionId: String, private var questionCategory: String): RecyclerView.Adapter<QuestionThreadViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuestionThreadViewHolder {
        val binding = QuestionThreadViewHolderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return QuestionThreadViewHolder((binding))
    }

    // display each reply in a card view
    override fun onBindViewHolder(holder: QuestionThreadViewHolder, position: Int) {
        holder.binding.replyCardBody.text = replies[position].description
//        holder.binding.replyReplyButton.setOnClickListener({
//            val intent = Intent(holder.binding.root.context, NewReplyActivity::class.java)
//            intent.putExtra("question_category", questionCategory)
//            intent.putExtra("question_id", questionId)
//            intent.putExtra("parent_id", replies[position].reply_id)
//            intent.putExtra("reply_thread", true)
//            holder.binding.root.context.startActivity(intent)
//        })
    }

    override fun getItemCount(): Int {
        return replies.size
    }

}