package com.example.cmpt362.duckdebugging.ui.questionThreadPage

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.QuestionThreadViewHolderBinding
import com.example.cmpt362.duckdebugging.models.replies.Reply

class QuestionThreadRecyclerViewAdapter(private var replies: ArrayList<Reply>): RecyclerView.Adapter<QuestionThreadViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuestionThreadViewHolder {
        val binding = QuestionThreadViewHolderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return QuestionThreadViewHolder((binding))
    }

    override fun onBindViewHolder(holder: QuestionThreadViewHolder, position: Int) {
        holder.binding.replyCardBody.text = replies[position].description

    }

    override fun getItemCount(): Int {
        return replies.size
    }

}