package com.example.cmpt362.duckdebugging.models.users

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

// Parcelable makes it possible to pass the object via intent
@Parcelize
class User (
    val id: String = "",
    val firstName: String = "",
    val lastName: String = "",
    val email: String = "",
    val occupation: String ="",
    val image: String = "",
    val profileComplete: String = "0",
    var userToken: String = "") : Parcelable