package com.example.cmpt362.duckdebugging.ui.newsfeedTab

import android.content.Context
import androidx.lifecycle.ViewModel
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.cmpt362.duckdebugging.models.articles.Article
import com.google.gson.JsonObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch

/**
 * Used by the newsfeed fragment to interact with the NewsData API
 * Sends a GET request to the API to get a JSON array of articles
 * Iterates through the articles and appends them to an array, which is used by the recycler view adapter to display the articles
 */
class NewsfeedViewModel() : ViewModel() {
    // left the API key in the code, so that the TAs can run the code
    private val NEWS_DATA_API_KEY = "pub_14187867039c0309b65cbb5f079f6ad97f42e"

    //fetch the articles
    fun fetchArticles(context: Context, articles: ArrayList<Article>, adapter: NewsfeedRecyclerViewAdapter) {
        println("making request");
        val queue = Volley.newRequestQueue(context);

        // query for top articles written in English, from Canada, USA, Australia, and UK, in the Technology category
        val url = "https://newsdata.io/api/1/news?apikey=${NEWS_DATA_API_KEY}&language=en&country=au,ca,us,gb&category=technology"

        // send the request in a worker thread
        CoroutineScope(IO).launch {
            // construct a GET request with the query url
            val jsonObjectRequest = JsonObjectRequest(
                Request.Method.GET, url, null,
                Response.Listener {
                    // we receive a json array of articles
                    val newsJsonArray = it.getJSONArray("results")
                    println("received: $newsJsonArray")

                    // for each article, create an article object and append it to an array
                    for (i in 0..(newsJsonArray.length() - 1)) {
                        val newsJsonObject = newsJsonArray.getJSONObject(i)
                        val article = Article(
                            heading = newsJsonObject.getString("title"),
                            outlet = newsJsonObject.getString("source_id"),
                            url = newsJsonObject.getString("link"),
                            imageUrl = newsJsonObject.getString("image_url")
                        )
                        articles.add(article)
                        println("added article: $article")
                    }
                    // send the articles to the recycler view adapter
                    adapter.updateArticles(articles)
                },
                Response.ErrorListener {

                }
            )
            queue.add(jsonObjectRequest)
        }
    }
}