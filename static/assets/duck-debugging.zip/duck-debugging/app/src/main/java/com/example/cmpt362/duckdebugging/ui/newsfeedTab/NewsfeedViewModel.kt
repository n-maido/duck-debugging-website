package com.example.cmpt362.duckdebugging.ui.newsfeedTab

import android.content.Context
import androidx.lifecycle.ViewModel
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.cmpt362.duckdebugging.models.articles.Article
import com.google.gson.JsonObject

class NewsfeedViewModel : ViewModel() {
//    private val NEWS_API_KEY="ae00f9f5db4f408a83de6619db4ba407"
    private val NEWS_DATA_API_KEY = "pub_14187867039c0309b65cbb5f079f6ad97f42e"
    //fetch the articles
    fun fetchArticles(context: Context, articles: ArrayList<Article>, adapter: NewsfeedRecyclerViewAdapter) {
        println("making request");
        val queue = Volley.newRequestQueue(context);
//        val url = "https://newsapi.org/v2/top-headlines?category=technology&apiKey=${NEWS_API_KEY}"
        val url = "https://newsdata.io/api/1/news?apikey=${NEWS_DATA_API_KEY}&language=en&country=au,ca,us,gb&category=technology"
        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET,url,null,
            Response.Listener {
                // we receive a json array of articles
                val newsJsonArray = it.getJSONArray("results")
                println("received: $newsJsonArray")
                for (i in 0..(newsJsonArray.length()-1)) {
                    val newsJsonObject = newsJsonArray.getJSONObject(i)
                    val article = Article(
                        heading = newsJsonObject.getString("title"),
                        outlet = newsJsonObject.getString("source_id"),
                        url = newsJsonObject.getString("link"),
                        imageUrl = newsJsonObject.getString("image_url")
                    )
                    articles.add(article)
                    adapter.notifyDataSetChanged()
                    println("added article: $article")
                }
            },
            Response.ErrorListener {

            }
        )
        queue.add(jsonObjectRequest)
    }
}