package com.example.cmpt362.duckdebugging.ui.searchTab.categoryPage

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.QuestionViewHolderBinding
import com.example.cmpt362.duckdebugging.models.posts.Post

class QuestionRecyclerViewAdapter(val clickListener: QuestionClickListener, private var posts: ArrayList<Post>): RecyclerView.Adapter<QuestionViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuestionViewHolder {
        val binding = QuestionViewHolderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return QuestionViewHolder((binding))
    }

    override fun onBindViewHolder(holder: QuestionViewHolder, position: Int) {
        holder.binding.questionCardTitle.text = posts[position].title
        holder.binding.questionCardBody.text = posts[position].body

        holder.binding.questionCard.setOnClickListener {
            clickListener.onClickPost(posts[position], position)
        }
    }

    override fun getItemCount(): Int {
        return posts.size
    }

    fun setFilteredPosts(filteredPosts: ArrayList<Post>) {
        this.posts = filteredPosts
        notifyDataSetChanged()
    }
}