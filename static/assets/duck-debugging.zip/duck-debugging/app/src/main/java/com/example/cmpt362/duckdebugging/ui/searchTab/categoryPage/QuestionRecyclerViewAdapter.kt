package com.example.cmpt362.duckdebugging.ui.searchTab.categoryPage

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.QuestionViewHolderBinding
import com.example.cmpt362.duckdebugging.models.posts.Post

/**
 * Takes in a click listener and an array of posts/questions, and returns a view holder
 * For each post, update a card view to display the post info and pass the post to the click listener
 */
class QuestionRecyclerViewAdapter(val clickListener: QuestionClickListener, private var posts: ArrayList<Post>): RecyclerView.Adapter<QuestionViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuestionViewHolder {
        val binding = QuestionViewHolderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return QuestionViewHolder((binding))
    }

    // display each post in a card view
    override fun onBindViewHolder(holder: QuestionViewHolder, position: Int) {
        holder.binding.questionCardTitle.text = posts[position].title
        holder.binding.questionCardBody.text = posts[position].body

        holder.binding.questionCard.setOnClickListener {
            clickListener.onClickPost(posts[position], position)
        }
    }

    override fun getItemCount(): Int {
        return posts.size
    }

    // receive and update the filtered posts from the search view
    fun setFilteredPosts(filteredPosts: ArrayList<Post>) {
        this.posts = filteredPosts
        notifyDataSetChanged()
    }
}