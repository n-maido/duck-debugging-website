package com.example.cmpt362.duckdebugging.ui.postTab

import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.ListSelectionViewHolderBinding

class ListSelectionViewHolder(val binding: ListSelectionViewHolderBinding) : RecyclerView.ViewHolder(binding.root) {
}