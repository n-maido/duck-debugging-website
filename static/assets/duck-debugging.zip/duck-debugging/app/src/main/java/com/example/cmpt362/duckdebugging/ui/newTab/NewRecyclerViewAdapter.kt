package com.example.cmpt362.duckdebugging.ui.newTab

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.NewViewHolderBinding
import com.example.cmpt362.duckdebugging.models.users.NotificationModel
/**
 * Our custom recycleView adapter
 */
class NewRecyclerViewAdapter(val clickListener: NewClickListener,
                             private var notificationList: ArrayList<NotificationModel>): RecyclerView.Adapter<NewViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewViewHolder {

        val binding = NewViewHolderBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return NewViewHolder((binding))
    }

    override fun onBindViewHolder(holder: NewViewHolder, position: Int) {
        holder.binding.responderNameTileId.text = notificationList[position].responderName
        holder.binding.questionTileTileId.text = notificationList[position].reply_body
        holder.binding.newCard.setOnClickListener{
            clickListener.onClickNotification(notificationList[position].data_time,
                notificationList[position].question_id,
                notificationList[position].question_title,
                notificationList[position].reply_body,
                notificationList[position].responderName,
                notificationList[position].notificationId,
                notificationList[position].responderKeyForDeletion,
                position)
        }
    }


    override fun getItemCount(): Int {
        return notificationList.size
    }
}
