package com.example.cmpt362.duckdebugging.ui.searchTab.categoryPage

import com.example.cmpt362.duckdebugging.models.posts.Post

/**
 * onClick listener for each question card in the category page and the user profile
 */
interface QuestionClickListener {
    fun onClickPost(post: Post, position: Int)
}