package com.example.cmpt362.duckdebugging.ui.loginAndRegisterPage

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.*
import android.widget.Button

import androidx.activity.OnBackPressedCallback


import androidx.fragment.app.Fragment
import com.example.cmpt362.duckdebugging.MainActivity
import com.example.cmpt362.duckdebugging.R
import com.example.cmpt362.duckdebugging.models.firebase.FirebaseDataBaseClass
import com.example.cmpt362.duckdebugging.models.users.User

import com.example.cmpt362.duckdebugging.utils.Constants
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.auth.FirebaseAuth

class LoginFragment: Fragment() {

    private lateinit var registerTextView: Button
    private lateinit var loginButton : Button
    private lateinit var emailLoginEditText: TextInputLayout
    private lateinit var passwordLoginEditText: TextInputLayout
    private lateinit var forgetPasswordTextView: Button


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val v = inflater.inflate(R.layout.fragment_login, container, false)
        initializeMyWidget(v)

        val registerFragment = RegisterFragment()
        val forgetFragment = ForgetPasswordFragment()
        if(FirebaseDataBaseClass().userAuth()){
            FirebaseDataBaseClass().getCurrentUserDetails(this)
        }
        loginButton.setOnClickListener {
            logInRegisteredUser()
        }
        registerTextView.setOnClickListener {
            val transaction = requireActivity().supportFragmentManager.beginTransaction()
            transaction.setCustomAnimations(R.anim.enter_right_to_left, R.anim.exit_right_to_left,
            R.anim.enter_left_to_right,  R.anim.exit_left_to_right).replace(R.id.login_register_layout, registerFragment)
            transaction.commit()
        }
        forgetPasswordTextView.setOnClickListener{
            val transaction = requireActivity().supportFragmentManager.beginTransaction()
            transaction.setCustomAnimations( R.anim.enter_left_to_right, R.anim.exit_left_to_right,
                R.anim.enter_right_to_left, R.anim.exit_right_to_left
               ).replace(R.id.login_register_layout, forgetFragment)
            transaction.commit()
        }
        // This override function kills the app
        activity?.onBackPressedDispatcher?.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                requireActivity().finishAffinity()
            }
        })
        return v
    }

    private fun initializeMyWidget(v : View){
        registerTextView = v.findViewById(R.id.register_textView_id)
        loginButton = v.findViewById(R.id.login_button)
        emailLoginEditText = v.findViewById(R.id.email_login_id)
        passwordLoginEditText = v.findViewById(R.id.password_login_id)
        forgetPasswordTextView = v.findViewById(R.id.password_forget_id)
    }

    private fun validateLoginDetails(): Boolean{
        return when{
            TextUtils.isEmpty(emailLoginEditText.editText?.text.toString().trim{ it <= ' '}) ->{
                (activity as LoginRegisterActivity?)?.showErrorSnackBar(resources.getString(R.string.error_message_email), true)
                false
            }
            TextUtils.isEmpty(passwordLoginEditText.editText?.text.toString().trim{ it <= ' '}) ->{
                (activity as LoginRegisterActivity?)?.showErrorSnackBar(resources.getString(R.string.error_message_password), true)
                false
            }
            else -> {
                true
            }
        }
    }

    private fun logInRegisteredUser(){
        if(validateLoginDetails()){
            val email = emailLoginEditText.editText?.text.toString().trim{ it <= ' '}
            val password = passwordLoginEditText.editText?.text.toString().trim{ it <= ' '}
            // Login using FirebaseAuth
            FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                if(task.isSuccessful){
                    (activity as LoginRegisterActivity?)?.showErrorSnackBar("You are logged in successfully", false)
                    FirebaseDataBaseClass().getCurrentUserDetails(this)
                }
                else{
                    (activity as LoginRegisterActivity?)?.showErrorSnackBar(task.exception!!.message.toString(), true)
                }
            }
        }
    }
    // if the user is the first time login, then we would direct the user to profile fragment
    fun userLoggedInSuccess(user: User){
        Log.i("First Name: ", user.firstName)
        Log.i("Last Name: ", user.lastName)
        Log.i("Email: ", user.email)
        val intent = Intent(requireActivity(), MainActivity::class.java)
        if(user.profileComplete == "0") {
            intent.putExtra("not complete", "fill The profile")
            intent.putExtra(Constants.EXTRA_USER_DETAILS, user)
            startActivity(intent)
        }
        else{
            intent.putExtra(Constants.EXTRA_USER_DETAILS, user)
            startActivity(intent)
        }
        requireActivity().finish()
    }
}