package com.example.cmpt362.duckdebugging.ui.loginAndRegisterPage

import android.os.Build
import android.os.Bundle
import android.view.WindowInsets
import android.view.WindowManager

import com.example.cmpt362.duckdebugging.R
import com.example.cmpt362.duckdebugging.databinding.ActivityLoginRegisterBinding
/**
 * Host the register, login and forget fragments
 */
class LoginRegisterActivity: BaseActivity() {

    lateinit var binding: ActivityLoginRegisterBinding
    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        binding = ActivityLoginRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        getRidOfStatusBar()
        val loginFragment = LoginFragment()
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.login_register_layout, loginFragment)
        transaction.commit()
    }
    private fun getRidOfStatusBar(){
        @Suppress("DEPRECATION")
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.R){
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        }
        else{
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
            )
        }
    }
}