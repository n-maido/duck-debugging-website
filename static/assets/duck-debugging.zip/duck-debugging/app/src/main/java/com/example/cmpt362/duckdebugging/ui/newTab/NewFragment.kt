package com.example.cmpt362.duckdebugging.ui.newTab

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.R
import com.example.cmpt362.duckdebugging.databinding.FragmentNewBinding
import com.example.cmpt362.duckdebugging.models.firebase.FirebaseDataBaseClass
import com.example.cmpt362.duckdebugging.models.users.NotificationModel
import com.example.cmpt362.duckdebugging.models.users.User
import com.example.cmpt362.duckdebugging.ui.newTab.NotificationWindowActivity.NotificationWindowActivity
import com.example.cmpt362.duckdebugging.utils.Constants

var recyclerViewInNotificationWindow: RecyclerView? = null
/**
 * recycleView which holds all the upcoming notifications
 */
class NewFragment : Fragment(), NewClickListener {

    private var _binding: FragmentNewBinding? = null
    private lateinit var notificationList: ArrayList<NotificationModel>
    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    private lateinit var newViewModel: NewViewModel
    companion object{
        var value : String? = ""
        lateinit var userDetails: User
    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        newViewModel =
            ViewModelProvider(this).get(NewViewModel::class.java)

        _binding = FragmentNewBinding.inflate(inflater, container, false)
        val root: View = binding.root
        checkTheUserStatus()

        notificationList = ArrayList<NotificationModel>()
        recyclerViewInNotificationWindow= binding.newRecyclerView
        var adapter = ArrayAdapter<Any?>(requireActivity(), android.R.layout.simple_list_item_1,
            notificationList as List<Any?>)
        recyclerViewInNotificationWindow!!.layoutManager = LinearLayoutManager(requireContext())
        recyclerViewInNotificationWindow!!.adapter = NewRecyclerViewAdapter(this, notificationList)

        FirebaseDataBaseClass()
            .getNotificationList(this, notificationList, recyclerViewInNotificationWindow!!.adapter)
        adapter.setNotifyOnChange(true)
        activity?.onBackPressedDispatcher?.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                requireActivity().finishAffinity()
            }
        })
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun checkTheUserStatus(){

        value = requireActivity().intent.getStringExtra("not complete")
        if(value == "fill The profile"){
           Toast.makeText(requireActivity(), "Please completed your profile", Toast.LENGTH_LONG)
               .show()
        }
        if(requireActivity().intent.hasExtra(Constants.EXTRA_USER_DETAILS)) {
            userDetails = requireActivity().intent.getParcelableExtra(Constants.EXTRA_USER_DETAILS)!!


            FirebaseDataBaseClass().retrieveDeviceToken(this, userDetails)
        }
    }

    override fun onClickNotification(data_time: String, questionId: String, questiontitle: String,
                                     reply_body: String, responderName: String, notificationId : String
                                     , responderKeyForDeletion : String, position: Int) {
        val intent = Intent(requireActivity(), NotificationWindowActivity::class.java)
        intent.putExtra("data_time_notification_responder", data_time)
        intent.putExtra("question_id_notification", questionId)
        intent.putExtra("question_title_notification", questiontitle)
        intent.putExtra("reply_body_notification", reply_body)
        intent.putExtra("responder_name_notification", responderName)
        intent.putExtra("position_notification_list", position)
        intent.putExtra("notification_id", notificationId)
        intent.putExtra("responderKeyForDeletion", responderKeyForDeletion)
        startActivity(intent)
        requireActivity().overridePendingTransition(
            R.anim.slide_out_bottom,
            R.anim.slide_in_up);
    }



}