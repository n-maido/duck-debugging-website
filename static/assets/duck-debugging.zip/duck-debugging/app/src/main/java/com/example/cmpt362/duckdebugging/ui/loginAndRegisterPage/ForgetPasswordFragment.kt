package com.example.cmpt362.duckdebugging.ui.loginAndRegisterPage

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import com.example.cmpt362.duckdebugging.R
import com.example.cmpt362.duckdebugging.databinding.FragmentForgetPasswordBinding
import com.google.firebase.auth.FirebaseAuth

/**
 * This class sends the reset link to reset the password
 */

class ForgetPasswordFragment: Fragment() {

    private lateinit var binding : FragmentForgetPasswordBinding
    val loginFragment = LoginFragment()
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentForgetPasswordBinding.inflate(inflater, container, false)
        binding.submitButtonForgetId.setOnClickListener {
            val email: String = binding.emailForgetId.editText?.text.toString().trim { it <= ' ' }
            if (email.isEmpty()) {
                (activity as LoginRegisterActivity?)?.showErrorSnackBar(
                    resources.getString(R.string.error_message_email),
                    true
                )
            }
            else{
                FirebaseAuth.getInstance().sendPasswordResetEmail(email).addOnCompleteListener{task ->
                    if(task.isSuccessful){
                        (activity as LoginRegisterActivity?)?.showErrorSnackBar(
                            "Duck Debugging sent a password reset link to $email" +
                                    "! check your Spam folder ",
                            false
                        )
                        val transaction = requireActivity().supportFragmentManager.beginTransaction()
                        transaction.setCustomAnimations( R.anim.enter_right_to_left, R.anim.exit_right_to_left
                            ,R.anim.enter_left_to_right, R.anim.exit_left_to_right).
                        replace(R.id.login_register_layout, loginFragment)
                        transaction.commit()
                    }
                    else{
                        (activity as LoginRegisterActivity?)?.showErrorSnackBar(
                            task.exception!!.message.toString(),
                            true
                        )
                    }
                }
            }
        }
        activity?.onBackPressedDispatcher?.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val transaction = requireActivity().supportFragmentManager.beginTransaction()
                transaction.setCustomAnimations( R.anim.enter_right_to_left, R.anim.exit_right_to_left
                    ,R.anim.enter_left_to_right, R.anim.exit_left_to_right).
                replace(R.id.login_register_layout, loginFragment)
                transaction.commit()
            }
        })
        return binding.root
    }
}