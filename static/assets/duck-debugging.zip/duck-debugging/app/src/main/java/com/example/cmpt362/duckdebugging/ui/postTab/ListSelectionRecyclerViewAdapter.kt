package com.example.cmpt362.duckdebugging.ui.postTab

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.R
import com.example.cmpt362.duckdebugging.databinding.ListSelectionViewHolderBinding
import com.example.cmpt362.duckdebugging.ui.postTab.NewPostActivity

// class to display available topics for discussion
class ListSelectionRecyclerViewAdapter : RecyclerView.Adapter<ListSelectionViewHolder>() {
    val listTitle = arrayOf("Kotlin", "C++", "PHP", "Javascript")
    private lateinit var listItem: TextView
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListSelectionViewHolder {
        val binding = ListSelectionViewHolderBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return ListSelectionViewHolder((binding))
    }

    override fun onBindViewHolder(holder: ListSelectionViewHolder, position: Int) {
        if (listTitle[position].lowercase() == "kotlin") {
            holder.binding.postCardImage.setImageResource(com.example.cmpt362.duckdebugging.R.drawable.kotlin)
        } else if (listTitle[position].lowercase() == "c++") {
            holder.binding.postCardImage.setImageResource(com.example.cmpt362.duckdebugging.R.drawable.cpp)
        } else if (listTitle[position].lowercase() == "php") {
            holder.binding.postCardImage.setImageResource(com.example.cmpt362.duckdebugging.R.drawable.php)
        } else if (listTitle[position].lowercase() == "javascript") {
            holder.binding.postCardImage.setImageResource(com.example.cmpt362.duckdebugging.R.drawable.javascript)
        }

        // set title
        holder.binding.postCardTitle.text = listTitle[position]
        // when users click on a category, form to create new post is displayed
        holder.binding.postCard.setOnClickListener({
            // open activity to create new post under that category
            val intent: Intent = Intent(holder.itemView.context, NewPostActivity::class.java)
            intent.putExtra("category", listTitle[position])
            holder.itemView.context.startActivity(intent)
        })

    }

    override fun getItemCount(): Int {
        return listTitle.size
    }

}