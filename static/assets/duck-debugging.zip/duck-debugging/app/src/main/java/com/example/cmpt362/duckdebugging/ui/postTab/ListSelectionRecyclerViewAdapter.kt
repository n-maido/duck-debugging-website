package com.example.cmpt362.duckdebugging.ui.postTab

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.R
import com.example.cmpt362.duckdebugging.databinding.ListSelectionViewHolderBinding
import com.example.cmpt362.duckdebugging.ui.postTab.NewPostActivity

class ListSelectionRecyclerViewAdapter : RecyclerView.Adapter<ListSelectionViewHolder>() {
    val listTitle = arrayOf("Kotlin", "C++", "PHP", "Javascript")
    private lateinit var listItem: TextView
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListSelectionViewHolder {
        val binding = ListSelectionViewHolderBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return ListSelectionViewHolder((binding))
    }

    override fun onBindViewHolder(holder: ListSelectionViewHolder, position: Int) {
        holder.binding.itemNumber.text = (position + 1).toString()
        holder.binding.itemString.text = listTitle[position]
        holder.binding.itemString.setOnClickListener({
            // open activity to create new post under that category
            val intent: Intent = Intent(holder.itemView.context, NewPostActivity::class.java)
            intent.putExtra("category", listTitle[position])
            holder.itemView.context.startActivity(intent)
        })

    }

    override fun getItemCount(): Int {
        return listTitle.size
    }

}