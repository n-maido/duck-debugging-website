package com.example.cmpt362.duckdebugging.ui.searchTab

import android.R
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.FragmentSearchBinding
import com.example.cmpt362.duckdebugging.models.firebase.FirebaseDataBaseClass
import com.example.cmpt362.duckdebugging.ui.profileTab.SearchViewModel
import com.example.cmpt362.duckdebugging.ui.searchTab.categoryPage.CategoryActivity

/**
 * Displays all the post categories, in a recycler view
 * Each category is displayed in a card, held in a recycler view holder
 */
class SearchFragment : Fragment(), SearchClickListener {

    private var _binding: FragmentSearchBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
//    private lateinit var searchViewModel: SearchViewModel
    private lateinit var categories: ArrayList<String>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
//        searchViewModel = ViewModelProvider(this).get(SearchViewModel::class.java)


        _binding = FragmentSearchBinding.inflate(inflater, container, false)
        val root: View = binding.root

        //initialize the recycler view and adapter
        categories = ArrayList<String>()
        val recyclerView: RecyclerView = binding.searchRecyclerView
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = SearchRecyclerViewAdapter(this, categories)

        // get the categories from firebase
        FirebaseDataBaseClass().getCategories(this, categories, recyclerView.adapter)

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // when we click a category, go to its corresponding category page, which displays all the posts in that category
    override fun onClickCategory(category: String, position: Int) {
        val intent = Intent(requireActivity(), CategoryActivity::class.java)
        intent.putExtra("category", category)
        intent.putExtra("position", position)
        startActivity(intent)
    }
}