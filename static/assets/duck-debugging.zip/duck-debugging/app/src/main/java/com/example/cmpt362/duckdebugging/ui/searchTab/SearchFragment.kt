package com.example.cmpt362.duckdebugging.ui.searchTab

import android.R
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.FragmentSearchBinding
import com.example.cmpt362.duckdebugging.models.firebase.FirebaseDataBaseClass
import com.example.cmpt362.duckdebugging.ui.profileTab.SearchViewModel
import com.example.cmpt362.duckdebugging.ui.searchTab.categoryPage.CategoryActivity


class SearchFragment : Fragment(), SearchClickListener {

    private var _binding: FragmentSearchBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private lateinit var searchViewModel: SearchViewModel
    private lateinit var categories: ArrayList<String>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        searchViewModel =
            ViewModelProvider(this).get(SearchViewModel::class.java)


        _binding = FragmentSearchBinding.inflate(inflater, container, false)
        val root: View = binding.root

        //initialize adapter and pass to recycler view
        categories = ArrayList<String>()
        val recyclerView: RecyclerView = binding.searchRecyclerView
        var adapter = ArrayAdapter<Any?>(requireActivity(), R.layout.simple_list_item_1,
            categories as List<Any?>)


        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = SearchRecyclerViewAdapter(this, categories)
        FirebaseDataBaseClass().getCategories(this, categories, recyclerView.adapter)

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onClickCategory(category: String, position: Int) {
        val intent = Intent(requireActivity(), CategoryActivity::class.java)
        intent.putExtra("category", category)
        intent.putExtra("position", position)
        startActivity(intent)
    }
}