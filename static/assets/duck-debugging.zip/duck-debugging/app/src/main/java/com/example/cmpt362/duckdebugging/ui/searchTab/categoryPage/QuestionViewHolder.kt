package com.example.cmpt362.duckdebugging.ui.searchTab.categoryPage

import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.QuestionViewHolderBinding

/**
 * Holds a card view that displays a post
 * Used by the recycler view in the category page and profile tab
 */
class QuestionViewHolder(
    val binding: QuestionViewHolderBinding,
    ): RecyclerView.ViewHolder(binding.root) {
}