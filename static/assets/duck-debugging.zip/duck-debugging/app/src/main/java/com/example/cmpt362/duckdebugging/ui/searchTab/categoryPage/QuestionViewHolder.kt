package com.example.cmpt362.duckdebugging.ui.searchTab.categoryPage

import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.QuestionViewHolderBinding

class QuestionViewHolder(
    val binding: QuestionViewHolderBinding,
    ): RecyclerView.ViewHolder(binding.root) {
}