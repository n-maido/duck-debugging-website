package com.example.cmpt362.duckdebugging.ui.profileTab

import android.app.Activity.RESULT_OK
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.FragmentProfileBinding
import com.example.cmpt362.duckdebugging.models.firebase.FirebaseDataBaseClass
import com.example.cmpt362.duckdebugging.models.posts.Post
import com.example.cmpt362.duckdebugging.models.users.User
import com.example.cmpt362.duckdebugging.ui.loginAndRegisterPage.LoginFragment
import com.example.cmpt362.duckdebugging.ui.loginAndRegisterPage.LoginRegisterActivity
import com.example.cmpt362.duckdebugging.ui.newTab.NewFragment
import com.example.cmpt362.duckdebugging.ui.newTab.NewFragment.Companion.userDetails
import com.example.cmpt362.duckdebugging.ui.questionThreadPage.QuestionThreadActivity
import com.example.cmpt362.duckdebugging.ui.searchTab.categoryPage.QuestionClickListener
import com.example.cmpt362.duckdebugging.ui.searchTab.categoryPage.QuestionRecyclerViewAdapter
import com.example.cmpt362.duckdebugging.utils.Constants
import com.google.firebase.auth.FirebaseAuth


class ProfileFragment : Fragment(), QuestionClickListener {

    private lateinit var bitmap :Bitmap
    private var _binding: FragmentProfileBinding? = null
    lateinit var profileImage: ImageView
    lateinit var occupationEditText : EditText
    var flagToSeeIfTheUserUploadAPicture : Boolean = false

    // user's posts
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: QuestionRecyclerViewAdapter
    private lateinit var userPosts:ArrayList<Post>
    private lateinit var userPostsCategories: ArrayList<String>


    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val profileViewModel =
            ViewModelProvider(this).get(ProfileViewModel::class.java)
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        val root: View = binding.root
        val textView: TextView = binding.userFullName
        val firstNameEditText = binding.firstNameProfileId
        val lastNameEditText = binding.lastNameProfileId
        val saveButton = binding.saveButtonProfileId
        val logoutBtn = binding.logOutButtonProfileId
        occupationEditText = binding.occupationProfileId
        profileImage = binding.userImageId
        if(requireActivity().intent.hasExtra(Constants.EXTRA_USER_DETAILS)) {
            NewFragment.userDetails = requireActivity().intent.getParcelableExtra(Constants.EXTRA_USER_DETAILS)!!
        }

        firstNameEditText.isEnabled = false
        firstNameEditText.setText(userDetails.firstName)
        lastNameEditText.isEnabled = false
        lastNameEditText.setText(userDetails.lastName)
        if(userDetails.profileComplete != "0"){
            FirebaseDataBaseClass().loadImage(profileImage, this)
        }
        val sharedPreferences = requireActivity()
            .getSharedPreferences(Constants.DUCK_DEBUGGING_PREFERENCES, Context.MODE_PRIVATE)
        val email = sharedPreferences.getString(Constants.LOGGED_IN_USERNAME, "")!!
        textView.text = email
        profileImage.setOnClickListener{
            selectImage()
        }
        saveButton.setOnClickListener {
            if(validateUseProfile()){
                val userHashMap = HashMap<String, Any>()
                val occupation = occupationEditText.text.toString().trim{ it <= ' '}
                userHashMap[Constants.OCCUPATION] = occupation
                FirebaseDataBaseClass().updateUserProfileData(this, userHashMap)
                Toast.makeText(requireActivity(), "Your information update!", Toast.LENGTH_SHORT).show()
            }
            if(flagToSeeIfTheUserUploadAPicture){
                    FirebaseDataBaseClass()
                        .addAPictureToTheFirebaseStorage(this, profileImage, bitmap)
                flagToSeeIfTheUserUploadAPicture = false
            }
        }
       logoutBtn.setOnClickListener {
           FirebaseAuth.getInstance().signOut()
           val intent = Intent(requireActivity(), LoginRegisterActivity::class.java)
           startActivity(intent)
           requireActivity().finish()
       }
        // display user's posts
        userPosts = ArrayList<Post>()
        //        userPosts = arrayListOf(Post("title", "body"), Post("title", "body"), Post("title", "body"))
        userPostsCategories = ArrayList<String>()
        recyclerView = binding.userPostsRecyclerView
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        adapter = QuestionRecyclerViewAdapter(this, userPosts)
        recyclerView.adapter = adapter

        FirebaseDataBaseClass().getPostsByUserId(userPostsCategories, userPosts, adapter)
        //TODO: call firebase function to get user's posts

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun validateUseProfile(): Boolean{
        return when{
            TextUtils.isEmpty(occupationEditText.text.toString().trim { it <= ' '}) ->{
                Toast.makeText(requireActivity(), "Invalid occupation!", Toast.LENGTH_SHORT).show()
                false
            }
            else -> {
                true
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode == Constants.READ_STORAGE_PERMISSION_CODE){
            if(grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                selectImage()
            }
            else{
                Toast.makeText(requireActivity(), "The storage permission is denied",
                    Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun selectImage() {
        if (Build.VERSION.SDK_INT < 23) {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent,  1000)
        }
        if (Build.VERSION.SDK_INT >= 23) if (ContextCompat.checkSelfPermission(
                requireActivity(),
                android.Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 1000)
        } else {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, 1000)
        }
    }
    /*@JvmName("onRequestPermissionsResult1")
    fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String?>?,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions!!, grantResults)
        if (requestCode == 1000 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

        }
    }*/

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1000 && resultCode == RESULT_OK && data != null) {
            val chosenImageData = data.data
            try {
                bitmap =
                    MediaStore.Images.Media.getBitmap(requireActivity().contentResolver, chosenImageData)
                profileImage.setImageBitmap(bitmap)
                flagToSeeIfTheUserUploadAPicture = true
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onClickPost(post: Post, position: Int) {
        val intent = Intent(requireActivity(), QuestionThreadActivity::class.java)
        val postIndex = userPosts.indexOf(post)
        val postCategory: String = userPostsCategories[postIndex]
        intent.putExtra("category", postCategory)
//        intent.putExtra("category", post.category) // TODO: need to add the q's category
        intent.putExtra("questionTitle", post.title)
        intent.putExtra("questionBody", post.body)
        startActivity(intent)
    }

}
