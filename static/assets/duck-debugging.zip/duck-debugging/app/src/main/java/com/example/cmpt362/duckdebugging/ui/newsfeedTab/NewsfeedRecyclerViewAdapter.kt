package com.example.cmpt362.duckdebugging.ui.newsfeedTab

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.cmpt362.duckdebugging.databinding.NewsfeedViewholderBinding
import com.example.cmpt362.duckdebugging.models.articles.Article
import com.example.cmpt362.duckdebugging.models.posts.Post

class NewsfeedRecyclerViewAdapter(private val clickListener: NewsfeedClickListener, private var articles: ArrayList<Article>): RecyclerView.Adapter<NewsfeedViewHolder>() {
    private lateinit var context: Context;
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsfeedViewHolder {
        println("DEBUG: viewholder created. categories = $articles")
        val binding = NewsfeedViewholderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        context = parent.context
        return NewsfeedViewHolder((binding))
    }

    override fun onBindViewHolder(holder: NewsfeedViewHolder, position: Int) {
        println("DEBUG: viewholder bound. categories = $articles")
        val article = articles[position]

        //set image
        if (article.imageUrl != "null") {
            Glide.with(context).load(article.imageUrl).into(holder.binding.newsfeedCardImage)
        } else {
            // set default img if no img present
            holder.binding.newsfeedCardImage.setImageResource(com.example.cmpt362.duckdebugging.R.drawable.coding)
        }

        if (article.outlet != "null") {
            holder.binding.newsfeedCardOutlet.text = article.outlet
        } else holder.binding.newsfeedCardOutlet.text = ""

        holder.binding.newsfeedCardHeading.text = article.heading

        holder.binding.newsfeedCard.setOnClickListener{
            clickListener.onClickArticle(article.url)
        }
    }

    override fun getItemCount(): Int {
        println("DEBUG: category size = ${articles.size}")
        return articles.size
    }

    fun setFilteredArticles(filteredArticles: ArrayList<Article>) {
        this.articles = filteredArticles
        notifyDataSetChanged()
    }
}