package com.example.cmpt362.duckdebugging.ui.newsfeedTab

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.cmpt362.duckdebugging.databinding.NewsfeedViewholderBinding
import com.example.cmpt362.duckdebugging.models.articles.Article
import com.example.cmpt362.duckdebugging.models.posts.Post

/**
 * Takes in a click listener and an array of articles, and returns a view holder
 * For each article, update a card view to display the article info and passes the article url to the click listener
 */
class NewsfeedRecyclerViewAdapter(private val clickListener: NewsfeedClickListener, private var articles: ArrayList<Article>): RecyclerView.Adapter<NewsfeedViewHolder>() {
    private lateinit var context: Context;
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsfeedViewHolder {
        println("DEBUG: viewholder created. articles = $articles")
        val binding = NewsfeedViewholderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        context = parent.context
        return NewsfeedViewHolder((binding))
    }

    // display each article in a card view
    override fun onBindViewHolder(holder: NewsfeedViewHolder, position: Int) {
        println("DEBUG: viewholder bound. articles = $articles")
        val article = articles[position]

        //set image
        if (article.imageUrl != "null") {
            // use glide to load an image from a url into the image view
            Glide.with(context).load(article.imageUrl).into(holder.binding.newsfeedCardImage)
        } else {
            // set default img if no img present
            holder.binding.newsfeedCardImage.setImageResource(com.example.cmpt362.duckdebugging.R.drawable.coding)
        }

        if (article.outlet != "null") {
            holder.binding.newsfeedCardOutlet.text = article.outlet
        } else holder.binding.newsfeedCardOutlet.text = ""

        holder.binding.newsfeedCardHeading.text = article.heading

        holder.binding.newsfeedCard.setOnClickListener{
            clickListener.onClickArticle(article.url)
        }
    }

    override fun getItemCount(): Int {
        println("DEBUG: articles size = ${articles.size}")
        return articles.size
    }

    // receive and update the articles from the view model and search view
    fun updateArticles(articles: ArrayList<Article>) {
        this.articles = articles
        notifyDataSetChanged()
    }

}