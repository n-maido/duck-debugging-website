package com.example.cmpt362.duckdebugging.ui.questionThreadPage

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.R
import com.example.cmpt362.duckdebugging.databinding.ActivityQuestionThreadBinding
import com.example.cmpt362.duckdebugging.models.firebase.FirebaseDataBaseClass
import com.example.cmpt362.duckdebugging.models.replies.Reply
import com.example.cmpt362.duckdebugging.ui.postTab.EditPostActivity
import com.example.cmpt362.duckdebugging.ui.postTab.replyPage.NewReplyActivity

/**
 * Displays a question and it's replies in a recycler view
 * Each reply is displayed in a card, held in a recycler view holder
 * Users can click a reply button under the question or its replies to create a reply
 */
class QuestionThreadActivity : AppCompatActivity() {
    private lateinit var binding: ActivityQuestionThreadBinding
    private lateinit var category: String
    private lateinit var questionTitle: String
    private lateinit var questionBody: String
    private lateinit var replies: ArrayList<Reply>
    private lateinit var postId: String

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: QuestionThreadRecyclerViewAdapter
    private lateinit var resultLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuestionThreadBinding.inflate(layoutInflater)

        // display question
        questionTitle = intent.getStringExtra("questionTitle").toString()
        questionBody = intent.getStringExtra("questionBody").toString()
        category = intent.getStringExtra("category").toString()
        postId = intent.getStringExtra("postId").toString()
        binding.headingThread.text = questionTitle
        binding.questionThreadBody.text = questionBody
        binding.questionEditButton.setOnClickListener{
            val editIntent = Intent(this, EditPostActivity::class.java)
            editIntent.putExtra("question_title", questionTitle)
            editIntent.putExtra("question_body", questionBody)
            editIntent.putExtra("postId", postId)
            editIntent.putExtra("question_category", category)
            resultLauncher.launch(editIntent)
        }

        // create a response
        binding.questionReplyButton.setOnClickListener {
            val replyIntent = Intent(this, NewReplyActivity::class.java)
            replyIntent.putExtra("question_category", category)
            replyIntent.putExtra("question_id", postId)
            replyIntent.putExtra("question_title", questionTitle)
            replyIntent.putExtra("reply_thread", false)
            startActivity(replyIntent)
        }

        // display responses
        replies = ArrayList<Reply>()
        recyclerView = binding.replyRecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = QuestionThreadRecyclerViewAdapter(replies, postId, category)
        recyclerView.adapter = adapter

        // get the replies from firebase
//        FirebaseDataBaseClass().getRepliesByPost(category, questionTitle, replies, adapter)
        FirebaseDataBaseClass().getRepliesByPost(category, postId, replies, adapter)

        // registers for new post input (title + body) when the users input in Edit Post form
        // only updates on successful update in database as well
        resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val newTitle = result.data!!.getStringExtra("new_title").toString()
                val newBody = result.data!!.getStringExtra("new_body").toString()
                questionTitle = newTitle
                questionBody = newBody
                binding.headingThread.text = questionTitle
                binding.questionThreadBody.text = questionBody
            }
        }

        setContentView(binding.root)
    }
}