package com.example.cmpt362.duckdebugging.ui.questionThreadPage

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.ActivityQuestionThreadBinding
import com.example.cmpt362.duckdebugging.models.firebase.FirebaseDataBaseClass
import com.example.cmpt362.duckdebugging.models.replies.Reply
import com.example.cmpt362.duckdebugging.ui.postTab.replyPage.NewReplyActivity

class QuestionThreadActivity : AppCompatActivity() {
    private lateinit var binding: ActivityQuestionThreadBinding
    private lateinit var category: String
    private lateinit var questionTitle: String
    private lateinit var questionBody: String
    private lateinit var replies: ArrayList<Reply>

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: QuestionThreadRecyclerViewAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuestionThreadBinding.inflate(layoutInflater)

        // display question
        questionTitle = intent.getStringExtra("questionTitle").toString()
        questionBody = intent.getStringExtra("questionBody").toString()
        category = intent.getStringExtra("category").toString()
        binding.headingThread.text = questionTitle
        binding.questionThreadBody.text = questionBody

        // create a response
        binding.questionReplyButton.setOnClickListener {
            val replyIntent = Intent(this, NewReplyActivity::class.java)
            replyIntent.putExtra("question_category", category)
            replyIntent.putExtra("question_id", questionTitle)
            startActivity(replyIntent)
        }

        // display responses
        replies = ArrayList<Reply>()
        recyclerView = binding.replyRecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = QuestionThreadRecyclerViewAdapter(replies)
        recyclerView.adapter = adapter
        FirebaseDataBaseClass().getRepliesByPost(category, questionTitle, replies, adapter)

        setContentView(binding.root)
    }
}