package com.example.cmpt362.duckdebugging.ui.newsfeedTab

interface NewsfeedClickListener {
    fun onClickArticle(url: String)
}