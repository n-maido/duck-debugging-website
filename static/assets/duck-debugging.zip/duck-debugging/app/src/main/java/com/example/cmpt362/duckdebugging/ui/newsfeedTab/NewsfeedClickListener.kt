package com.example.cmpt362.duckdebugging.ui.newsfeedTab

/**
 * onClick listener for each article card in the newsfeed tab
 */
interface NewsfeedClickListener {
    // takes in a url to the article webpage
    fun onClickArticle(url: String)
}