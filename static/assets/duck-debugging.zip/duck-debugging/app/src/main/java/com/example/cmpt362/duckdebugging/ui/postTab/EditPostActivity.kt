package com.example.cmpt362.duckdebugging.ui.postTab

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.cmpt362.duckdebugging.R
import com.example.cmpt362.duckdebugging.models.firebase.FirebaseDataBaseClass
import com.example.cmpt362.duckdebugging.models.posts.Post
import com.example.cmpt362.duckdebugging.models.replies.Reply
import com.example.cmpt362.duckdebugging.ui.questionThreadPage.QuestionThreadActivity
import java.util.UUID

class EditPostActivity : AppCompatActivity() {
    private lateinit var questionCategory: String
    private lateinit var questionBody: String
    private lateinit var questionTitle: String
    private lateinit var questionTitleView: EditText
    private lateinit var questionBodyView: EditText
    private lateinit var saveEditBtn: Button
    private lateinit var cancelEditBtn: Button
    private lateinit var postId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_post)
        questionCategory = intent.getStringExtra("question_category").toString()
        questionBody = intent.getStringExtra("question_body").toString()
        questionTitle = intent.getStringExtra("question_title").toString()
        postId = intent.getStringExtra("postId").toString()
        questionTitleView = findViewById(R.id.edit_post_question)
        questionTitleView.setText(questionTitle)
        questionBodyView = findViewById(R.id.question_edit_body_input)
        questionBodyView.setText(questionBody)
        saveEditBtn = findViewById(R.id.edit_post_btn)
        saveEditBtn.setOnClickListener{
            questionTitle = questionTitleView.text.toString()
            questionBody = questionBodyView.text.toString()
            FirebaseDataBaseClass().editQuestionForCategory(questionCategory, postId, questionBody, questionTitle, this)
        }
        cancelEditBtn = findViewById(R.id.edit_post_cancel_btn)
        cancelEditBtn.setOnClickListener{
            finish()
        }
    }

    // sends updated question's title and body back to QuestionThreadActivity
    // to display on front-end
    fun onPostSuccess() {
        Toast.makeText(this, "Edited question.", Toast.LENGTH_SHORT).show()
        val intent = Intent(this, QuestionThreadActivity::class.java)
        intent.putExtra("new_title", questionTitle)
        intent.putExtra("new_body", questionBody)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }
}