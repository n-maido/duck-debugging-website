package com.example.cmpt362.duckdebugging

import android.annotation.SuppressLint
import android.app.ActivityOptions
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.cmpt362.duckdebugging.ui.loginAndRegisterPage.LoginRegisterActivity

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity(){

    lateinit var topAnim : Animation
    lateinit var bottomAnim : Animation
    lateinit var image : ImageView
    lateinit var slogen : TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        getRidOfStatusBar()
        topAnim = AnimationUtils.loadAnimation(this, R.anim.top_animation)
        bottomAnim = AnimationUtils.loadAnimation(this, R.anim.bottom_animation)
        image = findViewById(R.id.imageViewInSplash)
        slogen = findViewById(R.id.slogan)
        image.setAnimation(topAnim)
        slogen.animation = bottomAnim
        Handler().postDelayed(
            {
                val intent = Intent(this, LoginRegisterActivity::class.java)
                var pair : android.util.Pair<View, String> =  android.util.Pair(image, "logo_image")

                var option : ActivityOptions = ActivityOptions.makeSceneTransitionAnimation(this, pair)
                startActivity(intent, option.toBundle())
            },
            4000
        )
    }
    private fun getRidOfStatusBar(){
        @Suppress("DEPRECATION")
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.R){
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        }
        else{
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
            )
        }
    }
}