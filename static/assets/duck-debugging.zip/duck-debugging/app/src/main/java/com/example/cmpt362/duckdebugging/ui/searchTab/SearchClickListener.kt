package com.example.cmpt362.duckdebugging.ui.searchTab

interface SearchClickListener {
    fun onClickCategory(category: String, position: Int)
}