package com.example.cmpt362.duckdebugging.ui.searchTab

/**
 * onClick listener for each category card in the search tab
 */
interface SearchClickListener {
    fun onClickCategory(category: String, position: Int)
}