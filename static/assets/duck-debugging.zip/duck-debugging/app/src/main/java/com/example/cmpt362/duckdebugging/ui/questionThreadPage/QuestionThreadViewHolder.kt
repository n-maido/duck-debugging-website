package com.example.cmpt362.duckdebugging.ui.questionThreadPage

import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.QuestionThreadViewHolderBinding

class QuestionThreadViewHolder(
    val binding: QuestionThreadViewHolderBinding
): RecyclerView.ViewHolder(binding.root) {
}