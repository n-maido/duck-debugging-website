package com.example.cmpt362.duckdebugging.ui.questionThreadPage

import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.QuestionThreadViewHolderBinding

/**
 * Holds a card view that displays an reply
 * Used by the recycler view in the question thread page
 */
class QuestionThreadViewHolder(
    val binding: QuestionThreadViewHolderBinding
): RecyclerView.ViewHolder(binding.root) {
}