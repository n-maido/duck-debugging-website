package com.example.cmpt362.duckdebugging.ui.loginAndRegisterPage

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import com.example.cmpt362.duckdebugging.R
import com.example.cmpt362.duckdebugging.models.firebase.FirebaseDataBaseClass
import com.example.cmpt362.duckdebugging.models.users.User
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

/**
 * Get the info from textview and register the user
 */

class RegisterFragment: Fragment() {
    private lateinit var loginTextView: Button
    private lateinit var firstNameEditText: TextInputLayout
    private lateinit var lastNameEditText: TextInputLayout
    private lateinit var occupationEditText: TextInputLayout
    private lateinit var emailEditText: TextInputLayout
    private lateinit var passwordEditText: TextInputLayout
    private lateinit var confirmPasswordEditText: TextInputLayout
    private lateinit var registerButton: Button
    private lateinit var checkBox: CheckBox
    val loginFragment = LoginFragment()
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val v = inflater.inflate(R.layout.fragment_register, container, false)
        // Initialize Firebase Auth
        initializeMyWidget(v)
        loginTextView.setOnClickListener {
            //requireActivity().onBackPressedDispatcher.onBackPressed()
            val transaction = requireActivity().supportFragmentManager.beginTransaction()
            transaction.setCustomAnimations( R.anim.enter_left_to_right, R.anim.exit_left_to_right,
                R.anim.enter_right_to_left, R.anim.exit_right_to_left
            ).replace(R.id.login_register_layout, loginFragment)
            transaction.commit()
        }
        registerButton.setOnClickListener {
            registerTheUser()
        }
        // onBackPressed is override
        activity?.onBackPressedDispatcher?.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val transaction = requireActivity().supportFragmentManager.beginTransaction()
                transaction.setCustomAnimations( R.anim.enter_left_to_right, R.anim.exit_left_to_right,
                    R.anim.enter_right_to_left, R.anim.exit_right_to_left
                ).replace(R.id.login_register_layout, loginFragment)
                transaction.commit()
            }
        })
        return v
    }

    private fun initializeMyWidget(v : View){
        loginTextView = v.findViewById(R.id.login_textView_id)
        firstNameEditText = v.findViewById(R.id.first_name_register_id)
        lastNameEditText = v.findViewById(R.id.last_name_register_id)
        occupationEditText = v.findViewById(R.id.occupation_register_id)
        registerButton = v.findViewById(R.id.register_button_register_id)
        emailEditText = v.findViewById(R.id.email_edittext_id)
        passwordEditText = v.findViewById(R.id.password_register_id)
        confirmPasswordEditText = v.findViewById(R.id.confirm_register_id)
        checkBox = v.findViewById(R.id.checkbox_terms)
    }

    private fun registerTheUser(){
        if(validateRegisterInputs()){
            val email: String = emailEditText.editText?.text.toString()
            val password: String = passwordEditText.editText?.text.toString()
            FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password).addOnCompleteListener(OnCompleteListener<AuthResult>{ task->
                if(task.isSuccessful){
                    val firebaseUser: FirebaseUser = task.result!!.user!!
                    val user =
                        User(firebaseUser.uid,firstNameEditText.editText?.text.toString().trim{ it <= ' '},
                            lastNameEditText.editText?.text.toString().trim{ it <= ' '},
                            emailEditText.editText?.text.toString().trim{ it <= ' '},
                        occupationEditText.editText?.text.toString().trim{ it <= ' '})
                    FirebaseDataBaseClass().registerUser(user)
                    (activity as LoginRegisterActivity?)?.showErrorSnackBar(
                        resources.getString(R.string.successful_register),
                        false
                    )
                    FirebaseAuth.getInstance().signOut()
                    val transaction = requireActivity().supportFragmentManager.beginTransaction()
                    transaction.setCustomAnimations( R.anim.enter_left_to_right, R.anim.exit_left_to_right,
                        R.anim.enter_right_to_left, R.anim.exit_right_to_left
                    ).replace(R.id.login_register_layout, loginFragment)
                    transaction.commit()
                }
                else{
                    (activity as LoginRegisterActivity?)?.showErrorSnackBar(
                        task.exception!!.message.toString(),
                        true
                    )
                }
            })
        }
    }

    private fun validateRegisterInputs(): Boolean{
        return when{
            TextUtils.isEmpty(firstNameEditText.editText?.text.toString().trim{ it <= ' '}) ->{
                (activity as LoginRegisterActivity?)?.showErrorSnackBar(resources.getString(R.string.error_message_first_name), true)
                false
            }
            TextUtils.isEmpty(lastNameEditText.editText?.text.toString().trim{ it <= ' '}) ->{
                (activity as LoginRegisterActivity?)?.showErrorSnackBar(resources.getString(R.string.error_message_last_name), true)
                false
            }
            TextUtils.isEmpty(occupationEditText.editText?.text.toString().trim{ it <= ' '}) ->{
                (activity as LoginRegisterActivity?)?.showErrorSnackBar(resources.getString(R.string.error_occupation_name), true)
                false
            }
            TextUtils.isEmpty(emailEditText.editText?.text.toString().trim{ it <= ' '}) ->{
                (activity as LoginRegisterActivity?)?.showErrorSnackBar(resources.getString(R.string.error_message_email), true)
                false
            }
            TextUtils.isEmpty(passwordEditText.editText?.text.toString().trim{ it <= ' '}) ->{
                (activity as LoginRegisterActivity?)?.showErrorSnackBar(resources.getString(R.string.error_message_password), true)
                false
            }
            TextUtils.isEmpty(confirmPasswordEditText.editText?.text.toString().trim{ it <= ' '}) ->{
                (activity as LoginRegisterActivity?)?.showErrorSnackBar(resources.getString(R.string.error_message_confirm_password), true)
                false
            }
            !checkBox.isChecked-> {
                (activity as LoginRegisterActivity?)?.showErrorSnackBar(resources.getString(R.string.error_terms_condition_message), true)
                false
            }
            else -> {
                if(passwordEditText.editText?.text.toString() != confirmPasswordEditText.editText?.text.toString()){
                    (activity as LoginRegisterActivity?)?.showErrorSnackBar(resources.getString(R.string.error_no_match_password), true)
                    false
                }
                else {
                 true
                }
            }
        }
    }

}