package com.example.cmpt362.duckdebugging.models.firebase

data class PushNotification(
    var data : NotificationData,
    var to : String
)
