package com.example.cmpt362.duckdebugging.models.firebase

data class NotificationData(
    var title : String,
    var message : String
)
