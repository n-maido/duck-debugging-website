package com.example.cmpt362.duckdebugging.models.firebase
/**
 * Notification model
 */
data class NotificationData(
    var title : String,
    var message : String
)
