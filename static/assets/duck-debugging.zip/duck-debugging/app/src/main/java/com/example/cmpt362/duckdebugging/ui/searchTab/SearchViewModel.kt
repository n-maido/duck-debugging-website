package com.example.cmpt362.duckdebugging.ui.profileTab

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.cmpt362.duckdebugging.models.firebase.FirebaseDataBaseClass

class SearchViewModel : ViewModel() {
    private val firebase: FirebaseDataBaseClass = FirebaseDataBaseClass()
     var categories = MutableLiveData<ArrayList<String>>()

    init {
//        categories.value = ArrayList<String>()
//        firebase.getCategories(this)
    }

    private val _text = MutableLiveData<String>().apply {
        value = "This is Search Fragment"
    }
    val text: LiveData<String> = _text

    fun setCategories(list: ArrayList<String>) {
        categories.value = list
        println("DEBUG: received list: $categories")
    }
}