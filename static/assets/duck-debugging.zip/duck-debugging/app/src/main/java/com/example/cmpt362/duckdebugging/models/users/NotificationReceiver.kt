package com.example.cmpt362.duckdebugging.models.users

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Notification model for receiving side
 */
@Parcelize
class NotificationReceiver (
    val id: String = "",
    var token: String = "" ): Parcelable