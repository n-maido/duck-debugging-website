package com.example.cmpt362.duckdebugging.models.users

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class NotificationReceiver (
    val id: String = "",
    var token: String = "" ): Parcelable