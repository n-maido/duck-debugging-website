package com.example.cmpt362.duckdebugging.ui.newsfeedTab

import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.NewsfeedViewholderBinding

/**
 * Holds a card view that displays an article
 * Used by the recycler view in the news tab
 */
class NewsfeedViewHolder(
    val binding: NewsfeedViewholderBinding
): RecyclerView.ViewHolder(binding.root)  {
}