package com.example.cmpt362.duckdebugging.ui.searchTab

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.SearchViewHolderBinding

class SearchRecyclerViewAdapter(val clickListener: SearchClickListener, private var categories: ArrayList<String>): RecyclerView.Adapter<SearchViewHolder>() {



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SearchViewHolder {
        println("DEBUG: viewholder created. categories = $categories")
        val binding = SearchViewHolderBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return SearchViewHolder((binding))
    }

    override fun onBindViewHolder(holder: SearchViewHolder, position: Int) {
        println("DEBUG: viewholder bound. categories = $categories")
        val categoryName = categories[position]
        // set imageview
        if (categoryName.lowercase() == "kotlin") {
            holder.binding.searchCardImage.setImageResource(com.example.cmpt362.duckdebugging.R.drawable.kotlin)
        } else if (categoryName.lowercase() == "c++") {
            holder.binding.searchCardImage.setImageResource(com.example.cmpt362.duckdebugging.R.drawable.cpp)
        } else if (categoryName.lowercase() == "php") {
            holder.binding.searchCardImage.setImageResource(com.example.cmpt362.duckdebugging.R.drawable.php)
        } else if (categoryName.lowercase() == "javascript") {
            holder.binding.searchCardImage.setImageResource(com.example.cmpt362.duckdebugging.R.drawable.javascript)
        }

        // set title
        holder.binding.searchCardTitle.text = categoryName

        holder.binding.searchCard.setOnClickListener{
            clickListener.onClickCategory(categories[position], position)
        }
    }

    override fun getItemCount(): Int {
        println("DEBUG: category size = ${categories.size}")
        return categories.size
    }


}