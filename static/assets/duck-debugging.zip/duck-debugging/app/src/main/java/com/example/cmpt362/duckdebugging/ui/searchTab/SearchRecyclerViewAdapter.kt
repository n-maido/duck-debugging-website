package com.example.cmpt362.duckdebugging.ui.searchTab

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.cmpt362.duckdebugging.databinding.SearchViewHolderBinding

/**
 * Takes in a click listener and an array of categories, and returns a view holder
 * For each category, update a card view to display the category info and pass the category to the click listener
 */
class SearchRecyclerViewAdapter(val clickListener: SearchClickListener, private var categories: ArrayList<String>): RecyclerView.Adapter<SearchViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SearchViewHolder {
        val binding = SearchViewHolderBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return SearchViewHolder((binding))
    }

    // display each category in a card view
    override fun onBindViewHolder(holder: SearchViewHolder, position: Int) {
        val categoryName = categories[position]
        // set the category image
        if (categoryName.lowercase() == "kotlin") {
            holder.binding.searchCardImage.setImageResource(com.example.cmpt362.duckdebugging.R.drawable.kotlin)
        } else if (categoryName.lowercase() == "c++") {
            holder.binding.searchCardImage.setImageResource(com.example.cmpt362.duckdebugging.R.drawable.cpp)
        } else if (categoryName.lowercase() == "php") {
            holder.binding.searchCardImage.setImageResource(com.example.cmpt362.duckdebugging.R.drawable.php)
        } else if (categoryName.lowercase() == "javascript") {
            holder.binding.searchCardImage.setImageResource(com.example.cmpt362.duckdebugging.R.drawable.javascript)
        }

        // set title
        holder.binding.searchCardTitle.text = categoryName

        holder.binding.searchCard.setOnClickListener{
            clickListener.onClickCategory(categories[position], position)
        }
    }

    override fun getItemCount(): Int {
        return categories.size
    }

}