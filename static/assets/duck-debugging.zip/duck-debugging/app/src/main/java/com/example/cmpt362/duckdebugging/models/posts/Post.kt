package com.example.cmpt362.duckdebugging.models.posts

import com.example.cmpt362.duckdebugging.models.replies.Reply
// content of a single Post object, postId is unique
class Post(val postId: String = "", var title: String = "", var body: String = "", val userId: String = "", var replies: ArrayList<Reply> = arrayListOf()) {

}