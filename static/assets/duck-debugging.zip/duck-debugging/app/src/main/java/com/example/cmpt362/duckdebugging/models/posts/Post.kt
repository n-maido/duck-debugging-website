package com.example.cmpt362.duckdebugging.models.posts

import com.example.cmpt362.duckdebugging.models.replies.Reply

//TODO: add post unique ID to set as post JSON key
class Post(val title: String = "", val body: String = "", val userId: String = "", val replies: ArrayList<Reply> = arrayListOf()) {

}