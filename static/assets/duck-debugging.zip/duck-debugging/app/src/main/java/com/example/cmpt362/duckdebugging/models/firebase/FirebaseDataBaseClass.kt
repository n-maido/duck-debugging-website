package com.example.cmpt362.duckdebugging.models.firebase

import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.util.Log
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

import com.example.cmpt362.duckdebugging.models.posts.Post
import com.example.cmpt362.duckdebugging.models.replies.Reply
import com.example.cmpt362.duckdebugging.models.users.NotificationModel
import com.example.cmpt362.duckdebugging.models.users.NotificationReceiver
import com.example.cmpt362.duckdebugging.models.users.User
import com.example.cmpt362.duckdebugging.ui.loginAndRegisterPage.LoginFragment
import com.example.cmpt362.duckdebugging.ui.postTab.EditPostActivity
import com.example.cmpt362.duckdebugging.ui.postTab.NewPostActivity
import com.example.cmpt362.duckdebugging.ui.postTab.replyPage.NewReplyActivity
import com.example.cmpt362.duckdebugging.ui.questionThreadPage.QuestionThreadRecyclerViewAdapter
import com.example.cmpt362.duckdebugging.ui.searchTab.categoryPage.CategoryActivity
import com.example.cmpt362.duckdebugging.ui.searchTab.categoryPage.QuestionRecyclerViewAdapter
import com.example.cmpt362.duckdebugging.utils.Constants
import com.example.cmpt362.duckdebugging.utils.Constants.COLLECTION_NOTIFICATION
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.storage.FirebaseStorage
import java.io.ByteArrayOutputStream
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

/**
    *This class responsible for all the interaction with firebase
 */

class FirebaseDataBaseClass {

    private lateinit var database: DatabaseReference

    /**
     * Register the user in Firebase
     */
    fun registerUser(userInfo: User) {
        database = Firebase.database.reference
        database.child(Constants.USERS).child(userInfo.id).setValue(userInfo).addOnSuccessListener {

        }
            .addOnFailureListener {

            }
    }
    /**
     * Get the current user ID
     */
    fun getCurrentUserID(): String {
        val currentUser = FirebaseAuth.getInstance().currentUser
        var currentUserId = ""
        if (currentUser != null) {
            currentUserId = currentUser.uid
        }
        return currentUserId
    }

    // posts a question under selected category in Post Tab, all questions are grouped
    // under their respective categories
    fun postQuestionForCategory(category: String, post: Post, activity: NewPostActivity) {
        database = Firebase.database.reference
        database.child(Constants.POSTS).child(category).child(post.postId).setValue(post)
            .addOnSuccessListener {
                Log.d("post question", "SUCCESS POST")
                activity.onPostSuccess()
            }.addOnFailureListener {
            Log.d("post question", "failure post")
        }
    }

    // separate modifications of a question/post's body and title in database, the question/post is found
    // based on order: posts -> category -> post's unique ID
    fun editQuestionForCategory(category: String, postId: String, body: String, title: String, editActivity: EditPostActivity) {
        database = Firebase.database.reference
        database.child(Constants.POSTS).child(category).child(postId).child("body").setValue(body)
            .addOnSuccessListener {
                Log.d("edit question", "SUCCESS EDIT")
            }.addOnFailureListener {
                Log.d("edit question", "failure edit")
            }
        database.child(Constants.POSTS).child(category).child(postId).child("title").setValue(title)
            .addOnSuccessListener {
                Log.d("edit question", "SUCCESS EDIT")
                editActivity.onPostSuccess()
            }.addOnFailureListener {
                Log.d("edit question", "failure edit")
            }
    }

    // find the provided post/question based on category + ID, add a Reply object to list of replies
    // list of replies is an array of Reply objects, each Reply has a unique ID
    fun postReplyToQuestion(
        questionCategory: String,
        questionId: String,
        reply: Reply,
        activity: NewReplyActivity
    ) {
        database = Firebase.database.reference
        database.child(Constants.POSTS).child(questionCategory).child(questionId)
            .child(Constants.REPLIES).child(reply.reply_id).setValue(reply).addOnSuccessListener {
            Log.d("reply question", "SUCCESS REPLY")
            activity.onReplySuccess()
        }.addOnFailureListener {
            Log.d("reply question", "failure to post reply")
        }
    }

    fun postReplyToReply(
        questionCategory: String,
        questionId: String,
        parentId: String,
        reply: Reply,
        activity: NewReplyActivity
    ) {
        database = Firebase.database.reference
        val questionRepliesRef = database.child(Constants.POSTS).child(questionCategory).child(questionId)
            .child(Constants.REPLIES).child(parentId)
        questionRepliesRef.child(Constants.REPLIES).child(reply.reply_id).setValue(reply).addOnSuccessListener {
                Log.d("reply question", "SUCCESS REPLY")
                activity.onReplySuccess()
            }.addOnFailureListener {
                Log.d("reply question", "failure to post reply")
            }
    }
    /**
     * Retrieve the notification detail for the usser
     */
    fun getNotificationList(fragment: Fragment,
                            notificationList: ArrayList<NotificationModel>,
                            adapter: RecyclerView.Adapter<RecyclerView.ViewHolder>?) {
        Firebase.database.reference.child(Constants.COLLECTION_NOTIFICATION)
            .child(getCurrentUserID()).child(Constants.REPLIES).get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val dataSnapshot: DataSnapshot = task.result
                    val children = dataSnapshot.children
                    children.forEach {
                        val secondSnapshot = it.key
                        Firebase.database.reference.child(Constants.COLLECTION_NOTIFICATION)
                            .child(getCurrentUserID())
                            .child(Constants.REPLIES).child(secondSnapshot.toString()).get()
                            .addOnCompleteListener { nestedTask ->
                                if (nestedTask.isSuccessful) {
                                    val secondNestedDataSnapshot: DataSnapshot = nestedTask.result
                                    val grandChildren = secondNestedDataSnapshot.children
                                    grandChildren.forEach { itTwo ->
                                        val thirdSnapShot = itTwo.key
                                        Firebase.database.reference.child(Constants.COLLECTION_NOTIFICATION)
                                            .child(getCurrentUserID())
                                            .child(Constants.REPLIES)
                                            .child(secondSnapshot.toString())
                                            .child(thirdSnapShot.toString())
                                            .get().addOnCompleteListener { nestedNestedTesk ->
                                                if (nestedNestedTesk.isSuccessful) {
                                                    val thirdNestedDataSnapshot: DataSnapshot =
                                                        nestedNestedTesk.result
                                                    val notificationDetails = NotificationModel(
                                                        thirdNestedDataSnapshot.child("reply_body").value.toString(),
                                                        thirdNestedDataSnapshot.child("data_time").value.toString(),
                                                        thirdNestedDataSnapshot.child("question_id").value.toString(),
                                                        thirdNestedDataSnapshot.child("question_title").value.toString(),
                                                        thirdNestedDataSnapshot.child("responderName").value.toString(),
                                                        thirdNestedDataSnapshot.child("notificationId").value.toString(),
                                                        thirdNestedDataSnapshot.child("responderKeyForDeletion").value.toString())
                                                    notificationList.add(notificationDetails)
                                                    if (adapter != null) {
                                                        adapter.notifyDataSetChanged()
                                                    }
                                                }
                                            }
                                    }

                                }
                            }
                    }
                }
            }
    }


    /**
     * Retrieves a reference to all the posts in the database
     * Iterates through them and appends the categories to an array, which is used to display them in the search tab
     */
    fun getCategories(
        fragment: Fragment,
        categoryList: ArrayList<String>,
        adapter: RecyclerView.Adapter<RecyclerView.ViewHolder>?
    ) {
        // get a reference to the posts in the database
        database = FirebaseDatabase.getInstance().getReference(Constants.POSTS)

        database.addChildEventListener(object : ChildEventListener {
            // for each category, grab the category name (which is the key) and append to an array of categories
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val category: String = snapshot.key.toString()
                Log.d("getCategories", category)
                categoryList.add(category)
                Log.d("getCategories", categoryList.toString())
                if (adapter != null) {
                    adapter.notifyDataSetChanged() // notify the recycler view adapter, so it can display the changes
                }

            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
            }

            override fun onChildRemoved(snapshot: DataSnapshot) {
            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {
            }

            override fun onCancelled(error: DatabaseError) {
            }

        })
    }


    /**
     * Retrieves a reference to all the posts under the given category
     * Iterates through them and appends the posts to an array, which is used to display them in the category page
     */
    fun getPostsByCategory(
        activity: CategoryActivity,
        category: String,
        posts: ArrayList<Post>,
        adapter: QuestionRecyclerViewAdapter
    ) {
        // Retrieves a reference to all the posts under the given category
        database = FirebaseDatabase.getInstance().getReference(Constants.POSTS).child(category)

        database.addChildEventListener(object : ChildEventListener {
            // for each post, create a post object and append to an array of posts
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val post = Post(
                    snapshot.child("postId").value.toString(),
                    snapshot.child("title").value.toString(),
                    snapshot.child("body").value.toString()
                )
                posts.add(post)
                if (adapter != null) {
                    adapter.notifyDataSetChanged() // notify the recycler view adapter, so it can display the changes
                }
            }

            // differentiate operations, onChildAdded will be executed when a unique post is created, i.e. unique post ID
            // onChildChanged should only modify contents (title + body) of targeted for editing post
            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                for (post in posts) {
                    if (post.postId.toString() == snapshot.key.toString()) {
                        post.title = snapshot.child("title").value.toString()
                        post.body = snapshot.child("body").value.toString()
                    }
                }
                if (adapter != null) {
                    adapter.notifyDataSetChanged()
                }
            }

            override fun onChildRemoved(snapshot: DataSnapshot) {
            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {
            }

            override fun onCancelled(error: DatabaseError) {
            }

        })
    }

    // specific function for displaying all users' posts in their profiles, function traverses
    // through all post categories, get all posts for each category, then if userId attached
    // to those posts correspond to current user's ID, add that to Profile's RecyclerViewAdapter
    fun getPostsByUserId(
        categories: ArrayList<String>,
        posts: ArrayList<Post>,
        adapter: QuestionRecyclerViewAdapter
    ) {
        database = FirebaseDatabase.getInstance().getReference(Constants.POSTS)

        val currentUserId: String = getCurrentUserID()

        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for (categorySnapshot in snapshot.children) {
                    database.child(categorySnapshot.key!!)
                        .addChildEventListener(object : ChildEventListener {
                            override fun onChildAdded(
                                childSnapshot: DataSnapshot,
                                previousChildName: String?
                            ) {
                                if (childSnapshot.child(Constants.USER_ID).value.toString() == currentUserId) {
                                    val postId = childSnapshot.child("postId").value.toString()
                                    var existsAlready = false
                                    // do not add duplicated posts to list of displayed users' posts
                                    for (post in posts) {
                                        if (post.postId == postId) {
                                            existsAlready = true
                                            // if post is already displayed, modify its body and title
                                            // to whatever the user submitted through Edit Post form (EditPostActivity)
                                            post.body = childSnapshot.child("body").value.toString()
                                            post.title = childSnapshot.child("title").value.toString()
                                            break
                                        }
                                    }
                                    if (!existsAlready) {
                                        val post = Post(
                                            postId,
                                            childSnapshot.child("title").value.toString(),
                                            childSnapshot.child("body").value.toString()
                                        )
                                        posts.add(post)
                                        categories.add(categorySnapshot.key.toString())
                                    }
                                    adapter.notifyDataSetChanged()
                                }
                            }

                            override fun onChildChanged(
                                snapshot: DataSnapshot,
                                previousChildName: String?
                            ) {
                            }

                            override fun onChildRemoved(snapshot: DataSnapshot) {
                            }

                            override fun onChildMoved(
                                snapshot: DataSnapshot,
                                previousChildName: String?
                            ) {
                            }

                            override fun onCancelled(error: DatabaseError) {
                            }
                        })
                }
            }

            override fun onCancelled(error: DatabaseError) {
            }
        })
    }

    /**
     * Retrieves a reference to all the replies under the given post, under the given category
     * Iterates through them and appends the posts to an array, which is used to display them in the category page
     */
    fun getRepliesByPost(
        category: String,
        questionId: String,
        replies: ArrayList<Reply>,
        adapter: QuestionThreadRecyclerViewAdapter?
    ) {
        // Retrieves a reference to all the replies under the given post, under the given category
        database = FirebaseDatabase.getInstance().getReference(Constants.POSTS).child(category)
            .child(questionId).child("replies")

        database.addChildEventListener(object : ChildEventListener {
            // for each reply, create a reply object and append to an array of replies
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val reply = Reply(
                    snapshot.child("description").value.toString(),
                    snapshot.child("userId").value.toString(),
                    snapshot.child("reply_id").value.toString(),
                )

                replies.add(reply)

                if (adapter != null) {
                    adapter.notifyDataSetChanged() // notify the recycler view adapter, so it can display the changes
                }
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                if (adapter != null) {
                    adapter.notifyDataSetChanged() // notify the recycler view adapter, so it can display the changes
                }
            }

            override fun onChildRemoved(snapshot: DataSnapshot) {
            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {
            }

            override fun onCancelled(error: DatabaseError) {
            }
        })
    }
    /**
     * Get user's details
     */
    fun getCurrentUserDetails(fragment: Fragment) {
        database = FirebaseDatabase.getInstance().getReference(Constants.USERS)
        database.child(getCurrentUserID()).get().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val dataSnapshot: DataSnapshot = task.result
                val user = User(
                    dataSnapshot.child(Constants.ID).value.toString(),
                    dataSnapshot.child(Constants.FIRST_NAME).value.toString(),
                    dataSnapshot.child(Constants.LAST_NAME).value.toString(),
                    dataSnapshot.child(Constants.EMAIL).value.toString(),
                    dataSnapshot.child(Constants.OCCUPATION).value.toString(),
                    dataSnapshot.child(Constants.IMAGE).value.toString(),
                    dataSnapshot.child(Constants.PROFILE_COMPLETED).value.toString()
                )
                val sharedPreferences = fragment.requireActivity().getSharedPreferences(
                    Constants.DUCK_DEBUGGING_PREFERENCES,
                    Context.MODE_PRIVATE
                )
                val editor: SharedPreferences.Editor = sharedPreferences.edit()
                editor.putString(Constants.LOGGED_IN_USERNAME, user.email).apply()

                when (fragment) {
                    is LoginFragment -> {
                        fragment.userLoggedInSuccess(user)
                    }
                }
            } else {
                when (fragment) {
                    is LoginFragment -> {
                        Log.e(
                            fragment.javaClass.simpleName,
                            "Error while getting user details."
                        )
                    }
                }
            }
        }
    }
    /**
     * Update the user's information in database
     */
    fun updateUserProfileData(fragment: Fragment, userHashMap: HashMap<String, Any>) {
        database = FirebaseDatabase.getInstance().getReference(Constants.USERS)
        database.child(getCurrentUserID()).updateChildren(userHashMap)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {

                } else {
                    Toast.makeText(
                        fragment.requireActivity(),
                        "Failed to update ",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
    }
    /**
     * Add a picture in firebase storage
     */
    fun addAPictureToTheFirebaseStorage(fragment: Fragment, imageView: ImageView, bitmap: Bitmap) {
        try {
            // Get the data from an ImageView as bytes
            imageView.isDrawingCacheEnabled = true
            imageView.buildDrawingCache()
            val baos = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
            val data = baos.toByteArray()
            database = FirebaseDatabase.getInstance().getReference(Constants.USERS)
            // Create a storage reference from our app
            // Create a reference to the file to delete
            val desertRef = FirebaseStorage.getInstance()
                .reference.child("${Constants.PROFILE_IMAGE_OF_USER_FIRE_STORE}/${getCurrentUserID()}/${Constants.MY_PROFILE_PICTURE}")
            // Delete the file
            desertRef.delete().addOnSuccessListener {
                // File deleted successfully
            }.addOnFailureListener {
                // Uh-oh, an error occurred!
            }
            val userImageHashMap = HashMap<String, Any>()
            userImageHashMap[Constants.IMAGE] = ""
            updateUserProfileData(fragment, userImageHashMap)

            FirebaseStorage.getInstance()
                .reference.child(Constants.PROFILE_IMAGE_OF_USER_FIRE_STORE)
                .child(getCurrentUserID().toString()).child(Constants.MY_PROFILE_PICTURE)
                .putBytes(data).addOnFailureListener {
                    // Handle unsuccessful uploads
                    Toast.makeText(
                        fragment.requireActivity(),
                        "Fail to update the image",
                        Toast.LENGTH_SHORT
                    ).show()
                }.addOnSuccessListener { taskSnapshot ->
                    // taskSnapshot.metadata contains file metadata such as size, content-type, etc.
                    // ...
                    //We are gonna add the name of the image to the user image
                    val userHashMap = HashMap<String, Any>()
                    userHashMap[Constants.IMAGE] = Constants.MY_PROFILE_PICTURE
                    updateUserProfileData(fragment, userHashMap)
                    val userHashMap2 = HashMap<String, Any>()
                    userHashMap2["profileComplete"] = 1
                    updateUserProfileData(fragment, userHashMap2)
                }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    /**
     * Load an image
     */
    fun loadImage(imageView: ImageView, fragment: Fragment) {
        try {
            val imageRef = FirebaseStorage.getInstance()
                .reference.child(Constants.PROFILE_IMAGE_OF_USER_FIRE_STORE)
                .child(getCurrentUserID().toString()).child(Constants.MY_PROFILE_PICTURE)
            imageRef.downloadUrl.addOnSuccessListener { Uri ->
                val imageURL = Uri.toString()
                Glide.with(fragment.requireActivity())
                    .load(imageURL)
                    .into(imageView)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    /**
     * Get the user Token for notification for identification
     */
    fun getTheUserIdForNotification(
        questionCategory: String,
        questionId: String,
        activity: NewReplyActivity
    ) {
        val database2 = FirebaseDatabase.getInstance().getReference(Constants.POSTS)
        database2.child(questionCategory).child(questionId).get().addOnCompleteListener { task ->

            if (task.isSuccessful) {
                val dataSnapshot: DataSnapshot = task.result
                val notifyReceiver =
                    NotificationReceiver(dataSnapshot.child("userId").value.toString())
                println(notifyReceiver.id)
                FirebaseDatabase.getInstance().getReference(Constants.USERS)
                    .child(notifyReceiver.id).get().addOnCompleteListener { it ->
                    if (it.isSuccessful) {
                        val dataSnapshot2: DataSnapshot = it.result
                        notifyReceiver.token = dataSnapshot2.child("userToken").value.toString()
                        val sharedPreferences = activity.getSharedPreferences(
                            Constants.DUCK_DEBUGGING_PREFERENCES,
                            Context.MODE_PRIVATE
                        )
                        val editor = sharedPreferences.edit()
                        editor.putString(Constants.NOTIFY_RECEIVER, notifyReceiver.token).apply()
                        editor.putString(Constants.NOTIFY_RECEIVER_ID, notifyReceiver.id).apply()
                    } else {

                    }
                }
            } else {

            }
        }
    }

    fun userAuth(): Boolean {
        val firebaseUser = FirebaseAuth.getInstance().currentUser
        if (firebaseUser != null) {
            return true
        }
        return false
    }
    /**
     * Get the unique device token
     */
    fun retrieveDeviceToken(fragment: Fragment, user: User) {
        val prefs: SharedPreferences =
            fragment.requireActivity().getSharedPreferences("TOKEN_PREF", MODE_PRIVATE)
        val token = prefs.getString("token", "")
        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (!task.isSuccessful) {
                return@OnCompleteListener
            }
            // Get new FCM registration token
            val token = task.result
            val editor: SharedPreferences.Editor =
                fragment.requireActivity()
                    .getSharedPreferences("TOKEN_PREF", MODE_PRIVATE).edit()
            if (token != null) {
                editor.putString("token", token)
                editor.apply()
                user.userToken = token
                val userHashMap = HashMap<String, Any>()
                userHashMap[Constants.USER_TOKEN] = token
                updateUserProfileData(fragment, userHashMap)
            }
        })

    }
    /**
     * This function and the next function take care of notification body
     */
    fun addNotificationToUser(
        ownerOfQuestionId: String, replyBody: String,
        responderId: String, data_time: String, question_id: String, question_title: String
    ) {
        Firebase.database.reference.child(Constants.COLLECTION_NOTIFICATION)
            .child(ownerOfQuestionId).setValue(responderId).addOnSuccessListener {
            }
            .addOnFailureListener {
            }

        addBodyToNotificationUser(
            ownerOfQuestionId, replyBody,
            responderId, data_time, question_id, question_title)

    }


    private fun addBodyToNotificationUser(
        ownerOfQuestionId: String, replyBody: String,
        responderId: String, data_time: String, question_id: String, question_title: String
    ) {

        database = Firebase.database.reference
        database.child(Constants.USERS).child(responderId)
            .get().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val dataSnapshot: DataSnapshot = task.result
                    val uniqueId = UUID.randomUUID().toString()
                    val notificationModel = NotificationModel(
                        replyBody,
                        data_time, question_id, question_title,
                        dataSnapshot.child(Constants.FIRST_NAME).value.toString(),
                        uniqueId,responderId
                    )
                    FirebaseDatabase.getInstance().getReference(COLLECTION_NOTIFICATION)
                        .child(ownerOfQuestionId).child(Constants.REPLIES)
                        .child(responderId).child(uniqueId)
                        .setValue(notificationModel)
                }
            }
    }
    /**
     * delete the notification from db
     */
    fun deleteANotification(keyForDeletion : String,notificationId: String,
                            adapter: RecyclerView.Adapter<RecyclerView.ViewHolder>?){
        Firebase.database.reference.child(Constants.COLLECTION_NOTIFICATION).child(getCurrentUserID())
            .child(Constants.REPLIES).child(keyForDeletion).child(notificationId).removeValue()
        adapter?.notifyDataSetChanged()
    }

}
